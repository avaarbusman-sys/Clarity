
CREATE TABLE public.planner_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  type text NOT NULL CHECK (type IN ('assignment','quiz','test','study_session')),
  title text NOT NULL,
  subject text,
  description text,
  due_date date NOT NULL,
  due_time time,
  priority text NOT NULL DEFAULT 'medium' CHECK (priority IN ('low','medium','high')),
  estimated_minutes integer,
  reminder text NOT NULL DEFAULT 'none' CHECK (reminder IN ('none','1w','3d','1d','3h','1h','at_due')),
  repeat text NOT NULL DEFAULT 'none' CHECK (repeat IN ('none','daily','weekly','monthly')),
  duration_minutes integer,
  goal text,
  linked_event_id uuid REFERENCES public.planner_events(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','completed','taken')),
  completed_at timestamptz,
  reminded_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.planner_events TO authenticated;
GRANT ALL ON public.planner_events TO service_role;

ALTER TABLE public.planner_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY "own planner_events" ON public.planner_events
  FOR ALL TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE TRIGGER planner_events_set_updated_at
  BEFORE UPDATE ON public.planner_events
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE INDEX planner_events_user_due_idx ON public.planner_events (user_id, due_date);
