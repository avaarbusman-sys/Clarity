// Analyze an uploaded file with Gemini multimodal and store structured study material.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const GATEWAY = "https://ai.gateway.lovable.dev/v1/chat/completions";
const MODEL = "google/gemini-2.5-flash";

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

const SYSTEM = `You are Clarity's document analyzer. You receive a school-related file (notes, quiz, test, worksheet, homework, textbook chapter, presentation, or image of handwritten work). Extract structured study material and return ONLY valid JSON matching this shape:
{
  "title": "short human title",
  "subject": "Math | Science | English | History | Other (best guess)",
  "doc_type": "notes | quiz | test | worksheet | homework | textbook | presentation | study_guide | other",
  "topics": ["..."],
  "vocabulary": [{"term":"...","definition":"..."}],
  "formulas": ["..."],
  "dates": ["..."],
  "key_concepts": ["..."],
  "summary": "3-6 sentence summary",
  "outline": ["heading or bullet"],
  "questions": [{"q":"...","a":"..."}],
  "flashcards": [{"front":"...","back":"..."}],
  "practice_questions": [{"q":"...","options":["a","b","c","d"],"answer":0,"explain":"..."}],
  "tags": ["..."],
  "extracted_text": "full plaintext content (use OCR for handwriting/images)"
}
Rules: If a field doesn't apply, use an empty array or empty string. Return 6-12 flashcards and 3-6 practice questions when the content supports it. For quizzes/tests, populate "questions" with the actual questions and answers when identifiable. Never wrap in markdown fences. Use LaTeX ($...$ inline, $$...$$ display) for any math.`;

function extractJson(text: string): any {
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/);
  const raw = fenced ? fenced[1] : text;
  const s = raw.indexOf("{");
  const e = raw.lastIndexOf("}");
  if (s === -1 || e === -1) throw new Error("No JSON in model response");
  return JSON.parse(raw.slice(s, e + 1));
}

function mimeFromName(name: string, fallback: string): string {
  const ext = name.split(".").pop()?.toLowerCase() ?? "";
  const map: Record<string, string> = {
    pdf: "application/pdf",
    png: "image/png",
    jpg: "image/jpeg",
    jpeg: "image/jpeg",
    webp: "image/webp",
    txt: "text/plain",
    md: "text/markdown",
    docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    pptx: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
  };
  return map[ext] || fallback || "application/octet-stream";
}

function toBase64(buf: ArrayBuffer): string {
  const bytes = new Uint8Array(buf);
  let bin = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    bin += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(bin);
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const apiKey = Deno.env.get("LOVABLE_API_KEY");
    if (!apiKey) throw new Error("LOVABLE_API_KEY not configured");

    const authHeader = req.headers.get("Authorization") ?? "";
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    const userClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const admin = createClient(supabaseUrl, serviceKey);

    const { data: userData, error: userErr } = await userClient.auth.getUser();
    if (userErr || !userData.user) return json({ error: "unauthorized" }, 401);
    const userId = userData.user.id;

    const { upload_id } = await req.json();
    if (!upload_id) return json({ error: "upload_id required" }, 400);

    const { data: row, error: rowErr } = await admin
      .from("uploads").select("*").eq("id", upload_id).eq("user_id", userId).maybeSingle();
    if (rowErr || !row) return json({ error: "not found" }, 404);

    await admin.from("uploads").update({ status: "processing", error: null }).eq("id", upload_id);

    // Download file from storage
    const { data: fileBlob, error: dlErr } = await admin.storage.from("uploads").download(row.file_path);
    if (dlErr || !fileBlob) throw new Error(`download failed: ${dlErr?.message}`);

    const mime = mimeFromName(row.file_name, row.file_type);
    const buf = await fileBlob.arrayBuffer();

    // Build user content block
    const userContent: any[] = [
      { type: "text", text: `Analyze this file (${row.file_name}). Extract structured study material.` },
    ];

    if (mime.startsWith("image/")) {
      const dataUrl = `data:${mime};base64,${toBase64(buf)}`;
      userContent.push({ type: "image_url", image_url: { url: dataUrl } });
    } else if (mime === "text/plain" || mime === "text/markdown") {
      const text = new TextDecoder().decode(buf).slice(0, 200_000);
      userContent[0] = { type: "text", text: `Analyze this file (${row.file_name}). Content follows:\n\n${text}` };
    } else {
      // PDF, DOCX, PPTX, etc. — send as file part
      const b64 = toBase64(buf);
      userContent.push({
        type: "file",
        file: { filename: row.file_name, file_data: `data:${mime};base64,${b64}` },
      });
    }

    const gwRes = await fetch(GATEWAY, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Lovable-API-Key": apiKey },
      body: JSON.stringify({
        model: MODEL,
        messages: [
          { role: "system", content: SYSTEM },
          { role: "user", content: userContent },
        ],
      }),
    });

    if (!gwRes.ok) {
      const t = await gwRes.text();
      throw new Error(`gateway ${gwRes.status}: ${t.slice(0, 500)}`);
    }
    const gw = await gwRes.json();
    const raw = gw.choices?.[0]?.message?.content ?? "";
    const analysis = extractJson(raw);

    const tags: string[] = Array.isArray(analysis.tags) ? analysis.tags.slice(0, 12) : [];

    await admin.from("uploads").update({
      status: "ready",
      title: analysis.title || row.file_name,
      subject: analysis.subject || null,
      doc_type: analysis.doc_type || null,
      extracted_text: analysis.extracted_text || null,
      tags,
      analysis,
      error: null,
    }).eq("id", upload_id);

    return json({ ok: true });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    console.error("analyze-upload:", msg);
    try {
      const { upload_id } = await req.clone().json().catch(() => ({}));
      if (upload_id) {
        const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
        await admin.from("uploads").update({ status: "error", error: msg.slice(0, 500) }).eq("id", upload_id);
      }
    } catch { /* noop */ }
    const status = msg.includes("429") ? 429 : msg.includes("402") ? 402 : 500;
    return json({ error: msg }, status);
  }
});
