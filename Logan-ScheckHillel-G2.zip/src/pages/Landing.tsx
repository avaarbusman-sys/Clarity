import { Link, Navigate } from "react-router-dom";
import {
  Sparkles,
  Layers,
  Brain,
  MessageCircle,
  UploadCloud,
  LineChart,
  BookOpen,
  ShieldCheck,
  ArrowRight,
  Loader2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import clarityLogo from "@/assets/clarity-logo.png.asset.json";

const features = [
  {
    icon: UploadCloud,
    title: "Upload anything",
    body: "PDFs, slides, worksheets, even photos of handwritten notes — parsed and organized automatically.",
  },
  {
    icon: Sparkles,
    title: "Instant study guides",
    body: "Turn any subject or uploaded file into a clean, structured guide with the key concepts pulled out.",
  },
  {
    icon: Layers,
    title: "Flashcards on demand",
    body: "Generate a full deck for a specific topic in seconds and review it until it sticks.",
  },
  {
    icon: Brain,
    title: "Adaptive quizzes",
    body: "Practice tests built from your own material, with explanations for every answer.",
  },
  {
    icon: MessageCircle,
    title: "AI tutor",
    body: "Ask questions in plain language and get step-by-step help with properly formatted math.",
  },
  {
    icon: LineChart,
    title: "Real progress tracking",
    body: "Actual study time and streaks — measured, not estimated.",
  },
];

const steps = [
  { n: "01", title: "Create your account", body: "Sign up with email or Google in a few seconds." },
  { n: "02", title: "Add your material", body: "Upload class files or just pick a subject to start from." },
  { n: "03", title: "Study smarter", body: "Guides, flashcards, quizzes and a tutor built around your work." },
];

export default function Landing() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center text-muted-foreground">
        <Loader2 className="h-5 w-5 animate-spin" />
      </div>
    );
  }
  if (user) return <Navigate to="/dashboard" replace />;

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="sticky top-0 z-30 px-4 pt-4">
        <div className="glass mx-auto max-w-6xl rounded-3xl px-5 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img
              src={clarityLogo.url}
              alt="Clarity logo"
              className="h-9 w-9 rounded-2xl object-cover shadow-[var(--shadow-soft)]"
            />
            <div>
              <div className="text-base font-semibold tracking-tight">Clarity</div>
              <div className="text-[11px] text-muted-foreground -mt-0.5">AI Study Companion</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button asChild variant="ghost" className="rounded-2xl hidden sm:inline-flex">
              <Link to="/auth">Sign in</Link>
            </Button>
            <Button asChild className="rounded-2xl">
              <Link to="/auth">Get started</Link>
            </Button>
          </div>
        </div>
      </header>

      <main>
        {/* Hero */}
        <section className="px-4 pt-16 pb-20">
          <div className="mx-auto max-w-3xl text-center">
            <div className="inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/5 px-3 py-1 text-xs font-medium text-primary">
              <Sparkles className="h-3.5 w-3.5" />
              Built for students, powered by AI
            </div>
            <h1 className="mt-6 text-4xl sm:text-6xl font-semibold tracking-tight leading-[1.05]">
              Your class material,
              <span className="block bg-[image:var(--gradient-primary)] bg-clip-text text-transparent">
                turned into real studying
              </span>
            </h1>
            <p className="mt-5 text-base sm:text-lg text-muted-foreground leading-relaxed">
              Upload notes, tests and slides — then get study guides, flashcards, quizzes and a
              tutor that actually knows your subjects. Sign in to unlock your workspace.
            </p>
            <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
              <Button asChild size="lg" className="rounded-2xl h-12 px-7 gap-2 w-full sm:w-auto">
                <Link to="/auth">
                  Create free account <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="rounded-2xl h-12 px-7 w-full sm:w-auto bg-card/60 hover:bg-card"
              >
                <Link to="/auth">I already have an account</Link>
              </Button>
            </div>
            <p className="mt-4 text-xs text-muted-foreground inline-flex items-center gap-1.5">
              <ShieldCheck className="h-3.5 w-3.5" />
              Your uploads stay private to your account
            </p>
          </div>
        </section>

        {/* Features */}
        <section className="px-4 pb-20">
          <div className="mx-auto max-w-6xl">
            <h2 className="text-2xl sm:text-3xl font-semibold tracking-tight text-center">
              Everything you need in one place
            </h2>
            <p className="mt-3 text-center text-muted-foreground text-sm sm:text-base">
              One workspace for every subject you're taking.
            </p>
            <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {features.map(({ icon: Icon, title, body }) => (
                <article key={title} className="glass rounded-3xl p-6 transition-transform hover:-translate-y-1">
                  <div className="h-11 w-11 rounded-2xl bg-primary/10 text-primary flex items-center justify-center">
                    <Icon className="h-5 w-5" />
                  </div>
                  <h3 className="mt-4 text-base font-semibold tracking-tight">{title}</h3>
                  <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{body}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* How it works */}
        <section className="px-4 pb-20">
          <div className="mx-auto max-w-5xl glass rounded-[2rem] p-8 sm:p-12">
            <h2 className="text-2xl sm:text-3xl font-semibold tracking-tight text-center">
              How Clarity works
            </h2>
            <div className="mt-10 grid gap-8 sm:grid-cols-3">
              {steps.map(({ n, title, body }) => (
                <div key={n}>
                  <div className="text-xs font-semibold tracking-[0.2em] text-primary">{n}</div>
                  <h3 className="mt-2 text-base font-semibold tracking-tight">{title}</h3>
                  <p className="mt-1.5 text-sm text-muted-foreground leading-relaxed">{body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="px-4 pb-24">
          <div className="mx-auto max-w-3xl text-center rounded-[2rem] p-10 sm:p-14 bg-[image:var(--gradient-primary)] text-primary-foreground shadow-[var(--shadow-elegant)]">
            <BookOpen className="h-8 w-8 mx-auto opacity-90" />
            <h2 className="mt-4 text-2xl sm:text-4xl font-semibold tracking-tight">
              Start studying in under a minute
            </h2>
            <p className="mt-3 text-sm sm:text-base opacity-90">
              Sign in to access your dashboard, uploads and AI tools.
            </p>
            <Button
              asChild
              size="lg"
              variant="secondary"
              className="mt-7 rounded-2xl h-12 px-8 gap-2"
            >
              <Link to="/auth">
                Sign in or sign up <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>
          </div>
        </section>
      </main>

      <footer className="px-4 pb-10">
        <div className="mx-auto max-w-6xl text-center text-xs text-muted-foreground">
          © {new Date().getFullYear()} Clarity — AI Study Companion
        </div>
      </footer>
    </div>
  );
}
