import { Link } from "react-router-dom";
import { Sparkles, Layers, Brain, ArrowRight, BookOpen } from "lucide-react";
import { PageHeader } from "@/components/layout/PageHeader";
import { useWeeklyStudyTime, formatDuration } from "@/hooks/useStudyTime";
import { useProfile, firstName, timeOfDayGreeting } from "@/hooks/useProfile";
import { useAuth } from "@/hooks/useAuth";
import { UpcomingPlannerCard } from "@/components/planner/UpcomingPlannerCard";

const quickActions = [
  {
    to: "/study-guide",
    title: "AI Study Guide",
    description: "Turn any notes into a clear study guide.",
    icon: Sparkles,
  },
  {
    to: "/flashcards",
    title: "Flashcards",
    description: "Review key ideas with quick flip cards.",
    icon: Layers,
  },
  {
    to: "/quiz",
    title: "Quiz Me",
    description: "Test yourself with mixed practice questions.",
    icon: Brain,
  },
];

export default function Dashboard() {
  const week = useWeeklyStudyTime();
  const totalSeconds = week.reduce((sum, d) => sum + d.seconds, 0);
  const max = Math.max(1, ...week.map((d) => d.seconds));
  const hasStudyData = totalSeconds > 0;
  const { profile } = useProfile();
  const { user } = useAuth();
  const name = firstName(profile, user?.email);
  const greeting = timeOfDayGreeting();

  return (
    <div className="max-w-6xl mx-auto">
      <PageHeader
        eyebrow="Welcome back"
        title={`${greeting}, ${name}.`}
        description="A calm, focused space for today's learning. Pick where you'd like to start."
      />


      {/* Quick actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        {quickActions.map(({ to, title, description, icon: Icon }, i) => (
          <Link
            key={to}
            to={to}
            className="glass rounded-3xl p-6 card-hover group animate-slide-up"
            style={{ animationDelay: `${i * 60}ms` }}
          >
            <div className="h-11 w-11 rounded-2xl bg-primary/10 text-primary flex items-center justify-center mb-4">
              <Icon className="h-5 w-5" />
            </div>
            <div className="text-lg font-semibold tracking-tight">{title}</div>
            <p className="text-sm text-muted-foreground mt-1">{description}</p>
            <div className="mt-4 flex items-center gap-1 text-sm text-primary font-medium">
              Open
              <ArrowRight className="h-3.5 w-3.5 group-hover:translate-x-0.5 transition-transform" />
            </div>
          </Link>
        ))}
      </div>

      <div className="mb-8">
        <UpcomingPlannerCard />
      </div>

      {/* Weekly progress */}
      <div className="glass rounded-3xl p-6 md:p-8">
        <div className="flex items-end justify-between mb-6">
          <div>
            <div className="text-xs uppercase tracking-[0.14em] text-primary font-medium">
              This week
            </div>
            <h3 className="text-xl font-semibold tracking-tight mt-1">Study minutes</h3>
          </div>
          <div className="text-sm text-muted-foreground">
            <span className="text-foreground font-semibold">{formatDuration(totalSeconds)}</span> total
          </div>
        </div>
        {hasStudyData ? (
          (() => {
            const maxMinutes = Math.max(1, max / 60);
            const steps = [1, 2, 5, 10, 15, 20, 30, 45, 60, 90, 120, 180, 240, 360, 480];
            const step = steps.find((s) => maxMinutes / s <= 4) ?? Math.ceil(maxMinutes / 4);
            const topMin = Math.ceil(maxMinutes / step) * step;
            const ticks: number[] = [];
            for (let t = 0; t <= topMin; t += step) ticks.push(t);
            const topSec = topMin * 60;
            return (
              <div className="flex gap-2 h-48">
                <div className="relative w-10 text-[10px] text-muted-foreground">
                  {ticks.map((t) => (
                    <div
                      key={t}
                      className="absolute right-0 -translate-y-1/2 pr-1 tabular-nums"
                      style={{ top: `${((topMin - t) / topMin) * 100}%` }}
                    >
                      {t}m
                    </div>
                  ))}
                </div>
                <div className="relative flex-1">
                  <div className="absolute inset-0 flex flex-col justify-between pointer-events-none">
                    {ticks.map((t) => (
                      <div key={t} className="h-px bg-border/60" />
                    ))}
                  </div>
                  <div className="relative h-full flex items-end gap-3 md:gap-5">
                    {week.map((d, idx) => (
                      <div key={`${d.date}-${idx}`} className="flex-1 flex flex-col items-center gap-2 h-full">
                        <div className="w-full flex-1 flex items-end">
                          <div
                            className="w-full rounded-t-xl gradient-bg opacity-90 transition-all"
                            style={{
                              height: `${d.seconds > 0 ? Math.max(3, (d.seconds / topSec) * 100) : 0}%`,
                            }}
                            title={`${d.day}: ${formatDuration(d.seconds)}`}
                          />
                        </div>
                        <div className="text-xs text-muted-foreground">{d.day}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            );
          })()
        ) : (
          <div className="h-40 rounded-2xl border border-dashed border-border/70 flex items-center justify-center text-center px-4">
            <p className="text-sm text-muted-foreground">
              No study time tracked yet — open a study page and your time will appear here.
            </p>
          </div>
        )}
      </div>

      <div className="mt-8 flex items-center gap-2 text-sm text-muted-foreground">
        <BookOpen className="h-4 w-4" />
        Sample content for demonstration.
      </div>
    </div>
  );
}
