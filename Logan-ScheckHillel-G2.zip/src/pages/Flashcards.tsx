import { useState } from "react";
import { ChevronLeft, ChevronRight, RotateCw, Sparkles, Loader2 } from "lucide-react";
import { PageHeader } from "@/components/layout/PageHeader";
import { aiFlashcards } from "@/lib/ai";
import { toast } from "@/hooks/use-toast";

interface Card {
  front: string;
  back: string;
}

export default function Flashcards() {
  const [subject, setSubject] = useState("");
  const [cards, setCards] = useState<Card[]>([]);
  const [i, setI] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [loading, setLoading] = useState(false);

  function go(dir: 1 | -1) {
    setFlipped(false);
    setTimeout(() => setI((v) => (v + dir + cards.length) % cards.length), 120);
  }

  async function generate(e?: React.FormEvent) {
    e?.preventDefault();
    if (!subject.trim() || loading) return;
    setLoading(true);
    try {
      const next = await aiFlashcards(subject.trim(), 8);
      if (!next?.length) throw new Error("No cards returned");
      setCards(next);
      setI(0);
      setFlipped(false);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Failed to generate";
      toast({ title: "Couldn't generate flashcards", description: msg, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="max-w-3xl mx-auto">
      <PageHeader
        eyebrow="Flashcards"
        title="Quick review deck"
        description="Enter a subject or topic to generate a set of flashcards."
      />

      <form onSubmit={generate} className="glass rounded-3xl p-4 mb-6 flex flex-col sm:flex-row gap-3">
        <input
          value={subject}
          onChange={(e) => setSubject(e.target.value)}
          placeholder="e.g. Photosynthesis, Algebra 1, WWII causes"
          disabled={loading}
          className="flex-1 bg-background/60 border border-border rounded-2xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary/40 transition"
        />
        <button
          type="submit"
          disabled={loading || !subject.trim()}
          className="inline-flex items-center justify-center gap-2 rounded-2xl px-5 py-3 gradient-bg text-primary-foreground font-medium shadow-[var(--shadow-soft)] hover:opacity-95 transition disabled:opacity-50"
        >
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
          {loading ? "Generating..." : "Generate"}
        </button>
      </form>

      {cards.length === 0 ? (
        <div className="glass rounded-3xl p-10 text-center text-muted-foreground">
          Enter a subject above and tap Generate to create your flashcards.
        </div>
      ) : (
        <>
          <div className="flex items-center justify-between text-sm text-muted-foreground mb-4">
            <div>Card {i + 1} of {cards.length}</div>
            <div className="inline-flex items-center gap-1.5">
              <RotateCw className="h-3.5 w-3.5" /> Tap to flip
            </div>
          </div>

          <div
            className="relative h-72 md:h-80 [perspective:1400px] cursor-pointer select-none"
            onClick={() => setFlipped((v) => !v)}
          >
            <div
              className="relative h-full w-full transition-transform duration-500 [transform-style:preserve-3d]"
              style={{ transform: flipped ? "rotateY(180deg)" : "rotateY(0)" }}
            >
              <FaceCard side="front" text={cards[i].front} label="Question" />
              <FaceCard side="back" text={cards[i].back} label="Answer" flipped />
            </div>
          </div>

          <div className="mt-6 flex items-center justify-between">
            <button
              onClick={() => go(-1)}
              className="inline-flex items-center gap-1.5 rounded-full px-4 py-2.5 glass hover:bg-accent/60 transition text-sm font-medium"
            >
              <ChevronLeft className="h-4 w-4" /> Previous
            </button>
            <div className="hidden sm:flex gap-1.5">
              {cards.map((_, idx) => (
                <div
                  key={idx}
                  className={`h-1.5 rounded-full transition-all ${
                    idx === i ? "w-8 bg-primary" : "w-1.5 bg-border"
                  }`}
                />
              ))}
            </div>
            <button
              onClick={() => go(1)}
              className="inline-flex items-center gap-1.5 rounded-full px-4 py-2.5 gradient-bg text-primary-foreground shadow-[var(--shadow-soft)] hover:opacity-95 transition text-sm font-medium"
            >
              Next <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </>
      )}
    </div>
  );
}

function FaceCard({
  side,
  text,
  label,
  flipped,
}: {
  side: "front" | "back";
  text: string;
  label: string;
  flipped?: boolean;
}) {
  return (
    <div
      className="absolute inset-0 glass-strong rounded-3xl p-8 flex flex-col items-center justify-center text-center [backface-visibility:hidden]"
      style={{ transform: flipped ? "rotateY(180deg)" : undefined }}
    >
      <div className="text-xs uppercase tracking-[0.14em] text-primary font-medium mb-4">
        {label}
      </div>
      <div className="text-xl md:text-2xl font-medium tracking-tight leading-relaxed max-w-xl">
        {text}
      </div>
      <div className="mt-6 text-xs text-muted-foreground">{side === "front" ? "Tap to reveal" : "Tap to hide"}</div>
    </div>
  );
}
