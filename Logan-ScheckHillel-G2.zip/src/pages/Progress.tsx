import { useEffect, useState } from "react";
import { PageHeader } from "@/components/layout/PageHeader";
import { useWeeklyStudyTime, formatDuration } from "@/hooks/useStudyTime";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { BarChart3, Trophy } from "lucide-react";
import { ImprovementCard } from "@/components/progress/ImprovementCard";
import { PlannerProductivityCard } from "@/components/planner/PlannerProductivityCard";

interface QuizResult {
  id: string;
  subject: string;
  score: number;
  total: number;
  percent: number;
  completed_at: string;
  difficulty: "easy" | "medium" | "hard" | null;
}

const DIFF_STYLES: Record<"easy" | "medium" | "hard", string> = {
  easy: "bg-success/15 text-success border-success/30",
  medium: "bg-primary/15 text-primary border-primary/30",
  hard: "bg-destructive/15 text-destructive border-destructive/30",
};

function formatDate(iso: string) {
  const d = new Date(iso);
  return d.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
}

export default function Progress() {
  const week = useWeeklyStudyTime();
  const totalSeconds = week.reduce((s, d) => s + d.seconds, 0);
  const maxT = Math.max(1, ...week.map((d) => d.seconds));
  const hasStudyData = totalSeconds > 0;

  const { user } = useAuth();
  const [results, setResults] = useState<QuizResult[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    let active = true;
    (async () => {
      const { data } = await supabase
        .from("quiz_results")
        .select("id, subject, score, total, percent, completed_at, difficulty")
        .order("completed_at", { ascending: false })
        .limit(50);
      if (!active) return;
      setResults((data as QuizResult[]) ?? []);
      setLoading(false);
    })();
    return () => {
      active = false;
    };
  }, [user]);

  // Subject progress = avg percent per subject across quizzes
  const subjectMap = new Map<string, { total: number; count: number }>();
  for (const r of results) {
    const key = r.subject.trim();
    if (!key) continue;
    const cur = subjectMap.get(key) ?? { total: 0, count: 0 };
    cur.total += r.percent;
    cur.count += 1;
    subjectMap.set(key, cur);
  }
  const subjectProgress = Array.from(subjectMap.entries())
    .map(([name, v]) => ({ name, pct: Math.round(v.total / v.count), count: v.count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 6);

  const recent = results.slice(0, 8);

  return (
    <div className="max-w-6xl mx-auto">
      <PageHeader
        eyebrow="Progress"
        title="Your learning at a glance"
        description="An overview of your real study time, subject coverage, and quiz results."
      />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <PlannerProductivityCard />
        <ImprovementCard results={results} />
        <div className="glass rounded-3xl p-6">
          <div className="flex items-baseline justify-between">
            <h3 className="text-lg font-semibold tracking-tight">Study time</h3>
            <div className="text-sm text-muted-foreground">
              <span className="text-foreground font-semibold">{formatDuration(totalSeconds)}</span> total
            </div>
          </div>
          <p className="text-sm text-muted-foreground">Minutes per day, this week.</p>
          {hasStudyData ? (
            (() => {
              // Build a nice Y-axis scale in minutes
              const maxMinutes = Math.max(1, maxT / 60);
              const niceStep = (v: number) => {
                const steps = [1, 2, 5, 10, 15, 20, 30, 45, 60, 90, 120, 180, 240, 360, 480];
                for (const s of steps) if (v / s <= 4) return s;
                return Math.ceil(v / 4);
              };
              const step = niceStep(maxMinutes);
              const topMin = Math.ceil(maxMinutes / step) * step;
              const ticks: number[] = [];
              for (let t = 0; t <= topMin; t += step) ticks.push(t);
              const topSec = topMin * 60;
              return (
                <div className="mt-6 flex gap-2 h-48">
                  <div className="relative w-10 text-[10px] text-muted-foreground">
                    {ticks
                      .slice()
                      .reverse()
                      .map((t) => (
                        <div
                          key={t}
                          className="absolute right-0 -translate-y-1/2 pr-1 tabular-nums"
                          style={{ top: `${((topMin - t) / topMin) * 100}%` }}
                        >
                          {t}m
                        </div>
                      ))}
                  </div>
                  <div className="relative flex-1">
                    <div className="absolute inset-0 flex flex-col justify-between pointer-events-none">
                      {ticks
                        .slice()
                        .reverse()
                        .map((t) => (
                          <div key={t} className="h-px bg-border/60" />
                        ))}
                    </div>
                    <div className="relative h-full flex items-end gap-3">
                      {week.map((d, idx) => (
                        <div key={`${d.date}-${idx}`} className="flex-1 flex flex-col items-center gap-2 h-full">
                          <div className="w-full flex-1 flex items-end">
                            <div
                              className="w-full rounded-t-xl gradient-bg opacity-90 transition-all"
                              style={{
                                height: `${d.seconds > 0 ? Math.max(3, (d.seconds / topSec) * 100) : 0}%`,
                              }}
                              title={`${d.day}: ${formatDuration(d.seconds)}`}
                            />
                          </div>
                          <div className="text-xs text-muted-foreground">{d.day}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              );
            })()
          ) : (
            <div className="mt-6 h-40 rounded-2xl border border-dashed border-border/70 flex flex-col items-center justify-center text-center px-4">
              <BarChart3 className="h-6 w-6 text-muted-foreground mb-2" />
              <p className="text-sm text-muted-foreground">
                No study time yet. Open a lesson or tutor session and your time will show up here.
              </p>
            </div>
          )}
        </div>

        <div className="glass rounded-3xl p-6">
          <h3 className="text-lg font-semibold tracking-tight">Subject progress</h3>
          <p className="text-sm text-muted-foreground">
            Average quiz score per subject.
          </p>
          {subjectProgress.length > 0 ? (
            <div className="mt-6 space-y-4">
              {subjectProgress.map((s) => (
                <div key={s.name}>
                  <div className="flex items-center justify-between text-sm mb-1.5">
                    <span className="font-medium">{s.name}</span>
                    <span className="text-muted-foreground">
                      {s.pct}% <span className="text-xs">· {s.count} quiz{s.count === 1 ? "" : "zes"}</span>
                    </span>
                  </div>
                  <div className="h-2 rounded-full bg-accent overflow-hidden">
                    <div
                      className="h-full rounded-full gradient-bg"
                      style={{ width: `${s.pct}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="mt-6 h-40 rounded-2xl border border-dashed border-border/70 flex flex-col items-center justify-center text-center px-4">
              <Trophy className="h-6 w-6 text-muted-foreground mb-2" />
              <p className="text-sm text-muted-foreground">
                Complete a quiz to see progress for that subject.
              </p>
            </div>
          )}
        </div>

        <div className="glass rounded-3xl p-6 lg:col-span-2">
          <h3 className="text-lg font-semibold tracking-tight">Recent quiz results</h3>
          <p className="text-sm text-muted-foreground">Your most recent completed quizzes.</p>
          {loading ? (
            <div className="mt-5 text-sm text-muted-foreground">Loading…</div>
          ) : recent.length > 0 ? (
            <div className="mt-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {recent.map((r) => (
                <div
                  key={r.id}
                  className="p-4 rounded-2xl bg-background/60 border border-border/70"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="text-sm font-medium truncate" title={r.subject}>
                      {r.subject}
                    </div>
                    {r.difficulty && (
                      <span className={`shrink-0 inline-flex items-center px-1.5 py-0.5 rounded-full text-[10px] font-medium border capitalize ${DIFF_STYLES[r.difficulty]}`}>
                        {r.difficulty}
                      </span>
                    )}
                  </div>
                  <div className="text-xs text-muted-foreground mt-0.5">
                    {formatDate(r.completed_at)}
                  </div>
                  <div className="mt-3 flex items-baseline gap-2">
                    <div className="text-2xl font-semibold tracking-tight">
                      {r.score}
                      <span className="text-sm text-muted-foreground">/{r.total}</span>
                    </div>
                    <div className="text-xs text-primary font-medium">{r.percent}%</div>
                  </div>
                  <div className="mt-3 h-1.5 rounded-full bg-accent overflow-hidden">
                    <div className="h-full rounded-full gradient-bg" style={{ width: `${r.percent}%` }} />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="mt-6 h-32 rounded-2xl border border-dashed border-border/70 flex flex-col items-center justify-center text-center px-4">
              <Trophy className="h-6 w-6 text-muted-foreground mb-2" />
              <p className="text-sm text-muted-foreground">
                No quizzes yet. Take a quiz and your results will appear here automatically.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
