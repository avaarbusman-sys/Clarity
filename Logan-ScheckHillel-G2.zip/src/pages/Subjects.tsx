import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { PageHeader } from "@/components/layout/PageHeader";
import { subjects } from "@/data/subjects";

export default function Subjects() {
  return (
    <div className="max-w-6xl mx-auto">
      <PageHeader
        eyebrow="Library"
        title="Subjects"
        description="A small, curated set of sample subjects to explore study materials."
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {subjects.map((s, i) => (
          <Link
            key={s.slug}
            to={`/subjects/${s.slug}`}
            className="glass rounded-3xl p-6 card-hover relative overflow-hidden animate-slide-up"
            style={{ animationDelay: `${i * 60}ms` }}
          >
            <div
              className={`absolute -right-16 -top-16 h-48 w-48 rounded-full bg-gradient-to-br ${s.color} opacity-25 blur-2xl`}
            />
            <div className="relative">
              <div className="text-xs uppercase tracking-[0.14em] text-primary font-medium">
                Subject
              </div>
              <div className="mt-1 text-2xl font-semibold tracking-tight">{s.name}</div>
              <p className="text-muted-foreground mt-2">{s.tagline}</p>
              <div className="mt-5 inline-flex items-center gap-1 text-sm text-primary font-medium">
                View materials <ArrowRight className="h-3.5 w-3.5" />
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
