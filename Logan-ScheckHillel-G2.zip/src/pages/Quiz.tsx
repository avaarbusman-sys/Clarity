import { useEffect, useRef, useState } from "react";
import { CheckCircle2, XCircle, RotateCcw, Sparkles, Loader2 } from "lucide-react";
import { PageHeader } from "@/components/layout/PageHeader";
import { aiQuiz, type QuizDifficulty } from "@/lib/ai";
import { toast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

interface Question {
  q: string;
  options: string[];
  answer: number;
  explain: string;
}

const DIFFICULTY_META: Record<QuizDifficulty, { label: string; blurb: string; className: string }> = {
  easy: { label: "Easy", blurb: "Meaningful basics — build understanding.", className: "bg-success/15 text-success border-success/30" },
  medium: { label: "Medium", blurb: "Balanced, like a normal school quiz.", className: "bg-primary/15 text-primary border-primary/30" },
  hard: { label: "Hard", blurb: "Very challenging — exam / honors level.", className: "bg-destructive/15 text-destructive border-destructive/30" },
};

export default function Quiz() {
  const [subject, setSubject] = useState("");
  const [difficulty, setDifficulty] = useState<QuizDifficulty>("medium");
  const [quizDifficulty, setQuizDifficulty] = useState<QuizDifficulty>("medium");
  const [questions, setQuestions] = useState<Question[]>([]);
  const [i, setI] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [done, setDone] = useState(false);
  const [loading, setLoading] = useState(false);
  const savedRef = useRef(false);

  useEffect(() => {
    if (!done || savedRef.current || questions.length === 0) return;
    savedRef.current = true;
    const total = questions.length;
    const pct = Math.round((score / total) * 100);
    (async () => {
      const { data: auth } = await supabase.auth.getUser();
      const uid = auth.user?.id;
      if (!uid) return;
      await supabase.from("quiz_results").insert({
        user_id: uid,
        subject: subject.trim(),
        score,
        total,
        percent: pct,
        difficulty: quizDifficulty,
      });
    })();
  }, [done, questions.length, score, subject, quizDifficulty]);

  async function generate(e?: React.FormEvent) {
    e?.preventDefault();
    if (!subject.trim() || loading) return;
    setLoading(true);
    try {
      const qs = await aiQuiz(subject.trim(), 5, difficulty);
      if (!qs?.length) throw new Error("No questions returned");
      setQuestions(qs);
      setQuizDifficulty(difficulty);
      setI(0);
      setSelected(null);
      setScore(0);
      setDone(false);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Failed to generate";
      toast({ title: "Couldn't generate quiz", description: msg, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }

  function choose(idx: number) {
    if (selected !== null) return;
    setSelected(idx);
    if (idx === questions[i].answer) setScore((s) => s + 1);
  }

  function next() {
    if (i + 1 >= questions.length) {
      setDone(true);
    } else {
      setI(i + 1);
      setSelected(null);
    }
  }

  function restart() {
    setQuestions([]);
    setI(0);
    setSelected(null);
    setScore(0);
    setDone(false);
    savedRef.current = false;
  }

  if (questions.length === 0) {
    return (
      <div className="max-w-2xl mx-auto">
        <PageHeader
          eyebrow="Quiz Mode"
          title="Test what you know"
          description="Pick a subject and difficulty to generate a practice quiz."
        />
        <form onSubmit={generate} className="glass rounded-3xl p-4 space-y-3">
          <input
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            placeholder="e.g. Cell biology, Linear equations, WWII"
            disabled={loading}
            className="w-full bg-background/60 border border-border rounded-2xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary/40 transition"
          />
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="flex-1">
              <label className="block text-xs uppercase tracking-[0.14em] text-muted-foreground font-medium mb-1.5 px-1">
                Difficulty
              </label>
              <div className="relative">
                <select
                  value={difficulty}
                  onChange={(e) => setDifficulty(e.target.value as QuizDifficulty)}
                  disabled={loading}
                  className="w-full appearance-none bg-background/60 border border-border rounded-2xl px-4 py-3 pr-10 text-sm outline-none focus:ring-2 focus:ring-primary/40 transition cursor-pointer"
                >
                  <option value="easy">Easy — meaningful basics</option>
                  <option value="medium">Medium — normal school quiz</option>
                  <option value="hard">Hard — exam / honors level</option>
                </select>
                <div className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground text-xs">▾</div>
              </div>
              <p className="text-xs text-muted-foreground mt-1.5 px-1">{DIFFICULTY_META[difficulty].blurb}</p>
            </div>
            <button
              type="submit"
              disabled={loading || !subject.trim()}
              className="sm:self-end inline-flex items-center justify-center gap-2 rounded-2xl px-5 py-3 gradient-bg text-primary-foreground font-medium shadow-[var(--shadow-soft)] hover:opacity-95 transition disabled:opacity-50"
            >
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
              {loading ? "Generating..." : "Generate Quiz"}
            </button>
          </div>
        </form>
      </div>
    );
  }

  if (done) {
    const pct = Math.round((score / questions.length) * 100);
    return (
      <div className="max-w-2xl mx-auto">
        <PageHeader eyebrow="Results" title="Quiz complete" />
        <div className="glass rounded-3xl p-8 text-center animate-scale-in">
          <div className="mx-auto h-20 w-20 rounded-full gradient-bg flex items-center justify-center shadow-[var(--shadow-elegant)]">
            <Sparkles className="h-8 w-8 text-primary-foreground" />
          </div>
          <div className="mt-6 text-5xl font-semibold tracking-tight gradient-text">
            {score}/{questions.length}
          </div>
          <p className="text-muted-foreground mt-2">You scored {pct}% on {subject}.</p>
          <div className="mt-3 flex justify-center">
            <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium border ${DIFFICULTY_META[quizDifficulty].className}`}>
              {DIFFICULTY_META[quizDifficulty].label} difficulty
            </span>
          </div>
          <button
            onClick={restart}
            className="mt-8 inline-flex items-center gap-2 rounded-full px-5 py-3 gradient-bg text-primary-foreground font-medium shadow-[var(--shadow-elegant)] hover:opacity-95 transition"
          >
            <RotateCcw className="h-4 w-4" /> New Quiz
          </button>
        </div>
      </div>
    );
  }

  const current = questions[i];

  return (
    <div className="max-w-2xl mx-auto">
      <PageHeader
        eyebrow={`Quiz — ${subject}`}
        title="Test what you know"
        description="Choose the best answer. You'll see feedback right away."
      />

      <div className="flex items-center justify-between text-sm text-muted-foreground mb-4">
        <div className="flex items-center gap-2">
          <span>Question {i + 1} of {questions.length}</span>
          <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium border ${DIFFICULTY_META[quizDifficulty].className}`}>
            {DIFFICULTY_META[quizDifficulty].label}
          </span>
        </div>
        <div>Score: <span className="text-foreground font-semibold">{score}</span></div>
      </div>

      <div className="glass rounded-3xl p-6 md:p-8 animate-fade-in" key={i}>
        <h2 className="text-xl md:text-2xl font-medium tracking-tight leading-snug">
          {current.q}
        </h2>

        <div className="mt-6 space-y-3">
          {current.options.map((opt, idx) => {
            const isCorrect = idx === current.answer;
            const isSelected = selected === idx;
            const showState = selected !== null;
            return (
              <button
                key={idx}
                onClick={() => choose(idx)}
                disabled={showState}
                className={`w-full text-left p-4 rounded-2xl border transition-all flex items-center justify-between gap-3
                  ${
                    showState && isCorrect
                      ? "bg-success/10 border-success/40"
                      : showState && isSelected && !isCorrect
                      ? "bg-destructive/10 border-destructive/40"
                      : "bg-background/60 border-border hover:border-primary/50 hover:bg-accent/40"
                  }`}
              >
                <span className="text-sm md:text-base">{opt}</span>
                {showState && isCorrect && <CheckCircle2 className="h-5 w-5 text-success" />}
                {showState && isSelected && !isCorrect && (
                  <XCircle className="h-5 w-5 text-destructive" />
                )}
              </button>
            );
          })}
        </div>

        {selected !== null && (
          <div className="mt-6 p-4 rounded-2xl bg-accent/50 border border-border/60 animate-fade-in">
            <div className="text-xs uppercase tracking-[0.14em] text-primary font-medium mb-1">
              {selected === current.answer ? "Correct" : "Not quite"}
            </div>
            <p className="text-sm text-foreground/90">{current.explain}</p>
          </div>
        )}

        <div className="mt-6 flex justify-end">
          <button
            onClick={next}
            disabled={selected === null}
            className="inline-flex items-center gap-2 rounded-full px-5 py-3 gradient-bg text-primary-foreground font-medium shadow-[var(--shadow-soft)] hover:opacity-95 transition disabled:opacity-40 disabled:cursor-not-allowed"
          >
            {i + 1 === questions.length ? "See results" : "Next question"}
          </button>
        </div>
      </div>
    </div>
  );
}
