import { useState } from "react";
import { Moon, Sun, Info, Sparkles, LogOut, Loader2 } from "lucide-react";
import { PageHeader } from "@/components/layout/PageHeader";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useProfile, firstName } from "@/hooks/useProfile";
import { toast } from "sonner";

export default function Settings() {
  const [dark, setDark] = useState<boolean>(
    typeof document !== "undefined" && document.documentElement.classList.contains("dark"),
  );
  const { user } = useAuth();
  const { profile } = useProfile();
  const [signingOut, setSigningOut] = useState(false);

  function toggle() {
    const next = !dark;
    setDark(next);
    document.documentElement.classList.toggle("dark", next);
  }

  async function signOut() {
    setSigningOut(true);
    try {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      window.location.href = "/";
    } catch (err: any) {
      toast.error(err.message ?? "Sign out failed");
      setSigningOut(false);
    }
  }

  return (
    <div className="max-w-3xl mx-auto">
      <PageHeader
        eyebrow="Settings"
        title="Preferences"
        description="A small set of visual preferences for this prototype."
      />

      <div className="glass rounded-3xl p-6 mb-5">
        <div className="flex items-start justify-between gap-4">
          <div>
            <div className="text-xs uppercase tracking-[0.14em] text-primary font-medium">
              Account
            </div>
            <div className="text-lg font-semibold tracking-tight mt-1">
              {firstName(profile, user?.email)}
            </div>
            <p className="text-sm text-muted-foreground mt-1">
              {user?.email ?? "Signed in"}
              {profile?.grade ? ` · ${profile.grade} grade` : ""}
            </p>
          </div>
          <Button
            variant="outline"
            onClick={signOut}
            disabled={signingOut}
            className="rounded-2xl gap-2"
          >
            {signingOut ? <Loader2 className="h-4 w-4 animate-spin" /> : <LogOut className="h-4 w-4" />}
            Sign out
          </Button>
        </div>
      </div>



      <div className="glass rounded-3xl p-6 mb-5">
        <div className="flex items-start justify-between gap-4">
          <div>
            <div className="text-xs uppercase tracking-[0.14em] text-primary font-medium">
              Appearance
            </div>
            <div className="text-lg font-semibold tracking-tight mt-1">Dark mode</div>
            <p className="text-sm text-muted-foreground mt-1">
              Switch between the light and dark theme. This preference is not saved.
            </p>
          </div>
          <button
            onClick={toggle}
            aria-pressed={dark}
            className={`relative h-8 w-14 rounded-full transition-colors ${
              dark ? "bg-primary" : "bg-accent"
            }`}
          >
            <span
              className={`absolute top-1 h-6 w-6 rounded-full bg-white shadow-md transition-all flex items-center justify-center ${
                dark ? "left-7" : "left-1"
              }`}
            >
              {dark ? (
                <Moon className="h-3.5 w-3.5 text-primary" />
              ) : (
                <Sun className="h-3.5 w-3.5 text-primary" />
              )}
            </span>
          </button>
        </div>

        <div className="mt-6 grid grid-cols-2 gap-3">
          <ThemePreview label="Light" dark={false} active={!dark} />
          <ThemePreview label="Dark" dark active={dark} />
        </div>
      </div>

      <div className="glass rounded-3xl p-6">
        <div className="flex items-center gap-2 text-primary font-medium text-sm">
          <Info className="h-4 w-4" /> About the app
        </div>
        <h3 className="text-xl font-semibold tracking-tight mt-2 flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-primary" /> Clarity
        </h3>
        <p className="text-muted-foreground mt-2 leading-relaxed">
          Clarity is a calm, AI-powered study companion designed for middle and high school
          students. This is a visual prototype — every screen uses sample content to
          demonstrate the concept. No accounts, no data, no saved progress.
        </p>
        <div className="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-3 text-sm">
          <div className="p-4 rounded-2xl bg-accent/40 border border-border/60">
            <div className="font-medium">Version</div>
            <div className="text-muted-foreground">Prototype 0.1</div>
          </div>
          <div className="p-4 rounded-2xl bg-accent/40 border border-border/60">
            <div className="font-medium">Audience</div>
            <div className="text-muted-foreground">Grades 6–12</div>
          </div>
          <div className="p-4 rounded-2xl bg-accent/40 border border-border/60">
            <div className="font-medium">Status</div>
            <div className="text-muted-foreground">Concept demo</div>
          </div>
        </div>
      </div>
    </div>
  );
}

function ThemePreview({ label, dark, active }: { label: string; dark: boolean; active: boolean }) {
  return (
    <div
      className={`rounded-2xl p-1 border transition-all ${
        active ? "border-primary shadow-[var(--shadow-soft)]" : "border-border"
      }`}
    >
      <div
        className={`rounded-xl h-28 p-3 flex flex-col justify-between overflow-hidden ${
          dark ? "bg-[hsl(222,47%,6%)] text-white" : "bg-white text-slate-900"
        }`}
      >
        <div className="flex gap-1.5">
          <div className={`h-2 w-2 rounded-full ${dark ? "bg-sky-400" : "bg-blue-500"}`} />
          <div className={`h-2 w-8 rounded-full ${dark ? "bg-white/20" : "bg-slate-200"}`} />
        </div>
        <div className="space-y-1.5">
          <div className={`h-2 w-3/4 rounded-full ${dark ? "bg-white/20" : "bg-slate-200"}`} />
          <div className={`h-2 w-1/2 rounded-full ${dark ? "bg-white/10" : "bg-slate-100"}`} />
          <div
            className={`h-6 w-16 rounded-lg mt-2 ${
              dark ? "bg-gradient-to-r from-sky-400 to-blue-500" : "bg-gradient-to-r from-blue-500 to-sky-400"
            }`}
          />
        </div>
      </div>
      <div className="text-xs font-medium text-center py-2">{label}</div>
    </div>
  );
}
