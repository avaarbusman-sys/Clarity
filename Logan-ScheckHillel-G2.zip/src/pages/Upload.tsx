import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Navigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { PageHeader } from "@/components/layout/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator,
  DropdownMenuSub, DropdownMenuSubTrigger, DropdownMenuSubContent,
} from "@/components/ui/dropdown-menu";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { cn } from "@/lib/utils";
import {
  UploadCloud, Search, MoreHorizontal, FileText, FileImage, FileType2, Presentation,
  Folder as FolderIcon, Plus, Loader2, CheckCircle2, AlertCircle, Trash2, Download,
  Eye, Pencil, RefreshCw, Share2, FolderInput, Sparkles, X,
} from "lucide-react";
import { toast } from "sonner";
import { MarkdownMessage } from "@/components/MarkdownMessage";

type UploadRow = {
  id: string;
  file_name: string;
  file_path: string;
  file_type: string;
  file_size: number;
  title: string | null;
  subject: string | null;
  doc_type: string | null;
  tags: string[];
  status: "pending" | "uploading" | "processing" | "ready" | "error";
  error: string | null;
  analysis: any | null;
  extracted_text: string | null;
  folder_id: string | null;
  last_opened_at: string | null;
  created_at: string;
};

type Folder = { id: string; name: string; color: string };

const FOLDER_COLORS = ["blue", "cyan", "indigo", "emerald", "amber", "rose", "violet"];
const COLOR_CLASSES: Record<string, string> = {
  blue: "bg-blue-500/15 text-blue-600 border-blue-300/40",
  cyan: "bg-cyan-500/15 text-cyan-600 border-cyan-300/40",
  indigo: "bg-indigo-500/15 text-indigo-600 border-indigo-300/40",
  emerald: "bg-emerald-500/15 text-emerald-600 border-emerald-300/40",
  amber: "bg-amber-500/15 text-amber-700 border-amber-300/40",
  rose: "bg-rose-500/15 text-rose-600 border-rose-300/40",
  violet: "bg-violet-500/15 text-violet-600 border-violet-300/40",
};

const ACCEPTED = ".pdf,.docx,.pptx,.txt,.md,.png,.jpg,.jpeg,.webp";

function iconFor(name: string) {
  const ext = name.split(".").pop()?.toLowerCase();
  if (["png", "jpg", "jpeg", "webp", "gif"].includes(ext || "")) return FileImage;
  if (["pptx", "ppt"].includes(ext || "")) return Presentation;
  if (["docx", "doc"].includes(ext || "")) return FileType2;
  return FileText;
}

function formatSize(n: number) {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1024 / 1024).toFixed(1)} MB`;
}
function formatDate(iso: string | null) {
  if (!iso) return "—";
  const d = new Date(iso);
  return d.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
}

/* ---------------- Auth gate ---------------- */

function AuthPanel() {
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email, password,
          options: { emailRedirectTo: window.location.origin + "/upload" },
        });
        if (error) throw error;
        toast.success("Account created. You're signed in.");
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      }
    } catch (err: any) {
      toast.error(err.message ?? "Auth failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="max-w-md mx-auto">
      <div className="glass rounded-3xl p-8">
        <div className="flex items-center gap-2 text-primary mb-2">
          <Sparkles className="h-4 w-4" />
          <span className="text-xs uppercase tracking-[0.14em] font-medium">Sign in</span>
        </div>
        <h2 className="text-2xl font-semibold tracking-tight mb-1">
          {mode === "signin" ? "Welcome back" : "Create your account"}
        </h2>
        <p className="text-sm text-muted-foreground mb-6">
          Uploads are private to your account and encrypted at rest.
        </p>
        <form onSubmit={submit} className="space-y-3">
          <Input type="email" placeholder="you@school.edu" value={email} onChange={(e) => setEmail(e.target.value)} required />
          <Input type="password" placeholder="Password (min 6)" minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} required />
          <Button type="submit" disabled={busy} className="w-full">
            {busy && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            {mode === "signin" ? "Sign in" : "Sign up"}
          </Button>
        </form>
        <button
          type="button"
          onClick={() => setMode(mode === "signin" ? "signup" : "signin")}
          className="mt-4 text-sm text-muted-foreground hover:text-foreground transition-colors w-full text-center"
        >
          {mode === "signin" ? "New here? Create an account" : "Already have an account? Sign in"}
        </button>
      </div>
    </div>
  );
}

/* ---------------- Main page ---------------- */

export default function UploadPage() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="flex items-center justify-center py-24 text-muted-foreground">
        <Loader2 className="h-5 w-5 animate-spin" />
      </div>
    );
  }
  if (!user) {
    return <Navigate to="/auth" state={{ from: "/upload" }} replace />;
  }
  return <UploadWorkspace userId={user.id} />;
}

/* ---------------- Workspace ---------------- */

function UploadWorkspace({ userId }: { userId: string }) {
  const [rows, setRows] = useState<UploadRow[]>([]);
  const [folders, setFolders] = useState<Folder[]>([]);
  const [activeFolder, setActiveFolder] = useState<string | "all" | "unfiled">("all");
  const [query, setQuery] = useState("");
  const [dragOver, setDragOver] = useState(false);
  const [progress, setProgress] = useState<Record<string, number>>({});
  const [preview, setPreview] = useState<UploadRow | null>(null);
  const [renameTarget, setRenameTarget] = useState<UploadRow | null>(null);
  const [renameValue, setRenameValue] = useState("");
  const [newFolderOpen, setNewFolderOpen] = useState(false);
  const [newFolderName, setNewFolderName] = useState("");
  const [newFolderColor, setNewFolderColor] = useState("blue");
  const fileInput = useRef<HTMLInputElement>(null);

  const load = useCallback(async () => {
    const [{ data: u }, { data: f }] = await Promise.all([
      supabase.from("uploads").select("*").order("created_at", { ascending: false }),
      supabase.from("folders").select("id,name,color").order("created_at", { ascending: true }),
    ]);
    setRows((u as UploadRow[]) ?? []);
    setFolders((f as Folder[]) ?? []);
  }, []);

  useEffect(() => { load(); }, [load]);

  // Realtime updates for processing status
  useEffect(() => {
    const channel = supabase
      .channel("uploads-changes")
      .on("postgres_changes", { event: "*", schema: "public", table: "uploads", filter: `user_id=eq.${userId}` },
        () => load())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [userId, load]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return rows.filter((r) => {
      if (activeFolder === "unfiled" && r.folder_id) return false;
      if (activeFolder !== "all" && activeFolder !== "unfiled" && r.folder_id !== activeFolder) return false;
      if (!q) return true;
      const hay = [r.title, r.file_name, r.subject, r.doc_type, (r.tags || []).join(" "), r.extracted_text]
        .filter(Boolean).join(" ").toLowerCase();
      return hay.includes(q);
    });
  }, [rows, query, activeFolder]);

  /* ---- Upload flow ---- */
  const startUpload = useCallback(async (files: FileList | File[]) => {
    const arr = Array.from(files);
    for (const file of arr) {
      const ext = file.name.split(".").pop()?.toLowerCase() ?? "";
      const path = `${userId}/${crypto.randomUUID()}.${ext}`;
      const tempKey = `${file.name}-${Date.now()}`;
      setProgress((p) => ({ ...p, [tempKey]: 5 }));

      try {
        setProgress((p) => ({ ...p, [tempKey]: 30 }));
        const { error: upErr } = await supabase.storage.from("uploads").upload(path, file, {
          contentType: file.type || "application/octet-stream",
        });
        if (upErr) throw upErr;
        setProgress((p) => ({ ...p, [tempKey]: 70 }));

        const insert = {
          user_id: userId,
          file_name: file.name,
          file_path: path,
          file_type: file.type || "application/octet-stream",
          file_size: file.size,
          folder_id: activeFolder !== "all" && activeFolder !== "unfiled" ? activeFolder : null,
          status: "processing" as const,
        };
        const { data: row, error: insErr } = await supabase.from("uploads").insert(insert).select().single();
        if (insErr) throw insErr;
        setProgress((p) => ({ ...p, [tempKey]: 90 }));

        // Fire-and-forget analysis (updates status via realtime)
        supabase.functions.invoke("analyze-upload", { body: { upload_id: row.id } })
          .catch((e) => console.error("analyze error", e));

        setProgress((p) => { const c = { ...p }; delete c[tempKey]; return c; });
        toast.success(`Uploaded ${file.name}`);
      } catch (err: any) {
        setProgress((p) => { const c = { ...p }; delete c[tempKey]; return c; });
        toast.error(`Failed: ${file.name}`, { description: err.message });
      }
    }
    load();
  }, [userId, activeFolder, load]);

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault(); setDragOver(false);
    if (e.dataTransfer.files?.length) startUpload(e.dataTransfer.files);
  };

  /* ---- Actions ---- */
  async function reprocess(row: UploadRow) {
    await supabase.from("uploads").update({ status: "processing", error: null }).eq("id", row.id);
    supabase.functions.invoke("analyze-upload", { body: { upload_id: row.id } })
      .catch((e) => toast.error("Reprocess failed", { description: e.message }));
    toast.info("Reprocessing…");
  }
  async function remove(row: UploadRow) {
    await supabase.storage.from("uploads").remove([row.file_path]);
    await supabase.from("uploads").delete().eq("id", row.id);
    toast.success("Deleted");
    load();
  }
  async function download(row: UploadRow) {
    const { data, error } = await supabase.storage.from("uploads").createSignedUrl(row.file_path, 60);
    if (error || !data) return toast.error("Download failed");
    window.open(data.signedUrl, "_blank");
  }
  async function openFile(row: UploadRow) {
    await supabase.from("uploads").update({ last_opened_at: new Date().toISOString() }).eq("id", row.id);
    setPreview(row);
  }
  async function share(row: UploadRow) {
    const { data } = await supabase.storage.from("uploads").createSignedUrl(row.file_path, 60 * 60 * 24);
    if (data?.signedUrl) {
      await navigator.clipboard.writeText(data.signedUrl);
      toast.success("Share link copied (valid 24h)");
    }
  }
  async function moveTo(row: UploadRow, folderId: string | null) {
    await supabase.from("uploads").update({ folder_id: folderId }).eq("id", row.id);
    toast.success("Moved");
    load();
  }
  async function rename() {
    if (!renameTarget) return;
    await supabase.from("uploads").update({ title: renameValue }).eq("id", renameTarget.id);
    setRenameTarget(null);
    load();
  }
  async function createFolder() {
    if (!newFolderName.trim()) return;
    await supabase.from("folders").insert({ user_id: userId, name: newFolderName.trim(), color: newFolderColor });
    setNewFolderName(""); setNewFolderOpen(false);
    load();
  }
  async function deleteFolder(id: string) {
    await supabase.from("folders").delete().eq("id", id);
    if (activeFolder === id) setActiveFolder("all");
    load();
  }

  const uploadingList = Object.entries(progress);

  return (
    <div>
      <PageHeader
        eyebrow="Upload"
        title="Your study library"
        description="Drop in tests, worksheets, notes, slides, or photos. Clarity extracts summaries, vocab, formulas, and practice questions automatically."
      >
        <div className="flex gap-2">
          <Button onClick={() => fileInput.current?.click()} className="gap-2">
            <UploadCloud className="h-4 w-4" /> Upload files
          </Button>
        </div>
      </PageHeader>

      <input
        ref={fileInput} type="file" multiple accept={ACCEPTED} className="hidden"
        onChange={(e) => { if (e.target.files) startUpload(e.target.files); e.target.value = ""; }}
      />

      <div className="grid grid-cols-1 lg:grid-cols-[240px_1fr] gap-6">
        {/* Folders sidebar */}
        <aside className="glass rounded-3xl p-4 h-max">
          <div className="flex items-center justify-between mb-3 px-1">
            <span className="text-xs uppercase tracking-[0.14em] font-medium text-muted-foreground">Folders</span>
            <button onClick={() => setNewFolderOpen(true)} className="h-7 w-7 rounded-lg hover:bg-accent flex items-center justify-center">
              <Plus className="h-4 w-4" />
            </button>
          </div>
          <div className="space-y-1">
            <FolderButton active={activeFolder === "all"} onClick={() => setActiveFolder("all")} color="blue" name={`All files (${rows.length})`} />
            <FolderButton active={activeFolder === "unfiled"} onClick={() => setActiveFolder("unfiled")} color="cyan" name="Unfiled" />
            {folders.map((f) => (
              <div key={f.id} className="group flex items-center">
                <FolderButton
                  active={activeFolder === f.id}
                  onClick={() => setActiveFolder(f.id)}
                  color={f.color} name={f.name}
                />
                <button
                  onClick={() => deleteFolder(f.id)}
                  className="opacity-0 group-hover:opacity-100 transition-opacity ml-1 h-6 w-6 rounded hover:bg-destructive/10 text-muted-foreground hover:text-destructive flex items-center justify-center"
                  aria-label="Delete folder"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>
            ))}
          </div>
        </aside>

        {/* Main */}
        <div className="space-y-6 min-w-0">
          {/* Drop zone */}
          <div
            onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
            onDragLeave={() => setDragOver(false)}
            onDrop={onDrop}
            onClick={() => fileInput.current?.click()}
            className={cn(
              "glass rounded-3xl border-2 border-dashed p-8 text-center cursor-pointer transition-all",
              dragOver ? "border-primary bg-primary/5 scale-[1.01]" : "border-primary/20 hover:border-primary/40",
            )}
          >
            <div className="mx-auto h-14 w-14 rounded-2xl gradient-bg flex items-center justify-center shadow-[var(--shadow-elegant)] mb-3">
              <UploadCloud className="h-7 w-7 text-white" />
            </div>
            <div className="font-semibold text-lg">Drop files here or click to browse</div>
            <p className="text-sm text-muted-foreground mt-1">
              PDF, DOCX, PPTX, TXT, PNG, JPG · multiple files supported
            </p>
          </div>

          {/* In-flight */}
          {uploadingList.length > 0 && (
            <div className="glass rounded-2xl p-4 space-y-2">
              {uploadingList.map(([k, v]) => (
                <div key={k}>
                  <div className="flex justify-between text-xs text-muted-foreground mb-1">
                    <span className="truncate max-w-[70%]">{k.split("-")[0]}</span>
                    <span>{v}%</span>
                  </div>
                  <Progress value={v} className="h-1.5" />
                </div>
              ))}
            </div>
          )}

          {/* Search */}
          <div className="relative">
            <Search className="h-4 w-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={query} onChange={(e) => setQuery(e.target.value)}
              placeholder="Search filename, topic, keyword, or text inside documents…"
              className="pl-10 h-11 rounded-2xl"
            />
          </div>

          {/* Grid */}
          {filtered.length === 0 ? (
            <div className="glass rounded-3xl p-12 text-center text-muted-foreground">
              {rows.length === 0 ? "No files yet — upload your first document above." : "No files match your search."}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {filtered.map((row) => (
                <FileCard
                  key={row.id} row={row} folders={folders}
                  onOpen={() => openFile(row)}
                  onPreview={() => openFile(row)}
                  onDownload={() => download(row)}
                  onDelete={() => remove(row)}
                  onReprocess={() => reprocess(row)}
                  onShare={() => share(row)}
                  onRename={() => { setRenameTarget(row); setRenameValue(row.title || row.file_name); }}
                  onMove={(fid) => moveTo(row, fid)}
                />
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Preview dialog */}
      <Dialog open={!!preview} onOpenChange={(o) => !o && setPreview(null)}>
        <DialogContent className="max-w-3xl max-h-[85vh] overflow-y-auto">
          {preview && <PreviewContent row={preview} onDownload={() => download(preview)} />}
        </DialogContent>
      </Dialog>

      {/* Rename dialog */}
      <Dialog open={!!renameTarget} onOpenChange={(o) => !o && setRenameTarget(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Rename file</DialogTitle></DialogHeader>
          <Input value={renameValue} onChange={(e) => setRenameValue(e.target.value)} />
          <DialogFooter>
            <Button variant="ghost" onClick={() => setRenameTarget(null)}>Cancel</Button>
            <Button onClick={rename}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* New folder */}
      <Dialog open={newFolderOpen} onOpenChange={setNewFolderOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>New folder</DialogTitle></DialogHeader>
          <Input placeholder="e.g. AP Biology" value={newFolderName} onChange={(e) => setNewFolderName(e.target.value)} />
          <div className="flex gap-2 flex-wrap">
            {FOLDER_COLORS.map((c) => (
              <button
                key={c} onClick={() => setNewFolderColor(c)}
                className={cn("h-8 w-8 rounded-full border-2 transition-all", COLOR_CLASSES[c], newFolderColor === c ? "ring-2 ring-primary ring-offset-2" : "")}
                aria-label={c}
              />
            ))}
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setNewFolderOpen(false)}>Cancel</Button>
            <Button onClick={createFolder}>Create</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

/* ---------------- Sub-components ---------------- */

function FolderButton({
  active, onClick, color, name,
}: { active: boolean; onClick: () => void; color: string; name: string }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "flex-1 flex items-center gap-2.5 px-3 py-2 rounded-xl text-sm text-left transition-all",
        active ? "bg-primary/10 text-primary shadow-[var(--shadow-soft)]" : "text-muted-foreground hover:text-foreground hover:bg-accent/60",
      )}
    >
      <span className={cn("h-6 w-6 rounded-lg flex items-center justify-center border", COLOR_CLASSES[color] || COLOR_CLASSES.blue)}>
        <FolderIcon className="h-3.5 w-3.5" />
      </span>
      <span className="truncate">{name}</span>
    </button>
  );
}

function StatusPill({ status }: { status: UploadRow["status"] }) {
  if (status === "processing" || status === "pending" || status === "uploading") {
    return <Badge variant="secondary" className="gap-1 font-normal"><Loader2 className="h-3 w-3 animate-spin" /> Analyzing</Badge>;
  }
  if (status === "ready") {
    return <Badge className="gap-1 bg-success/15 text-success hover:bg-success/20 border-success/20 font-normal"><CheckCircle2 className="h-3 w-3" /> Ready</Badge>;
  }
  return <Badge variant="destructive" className="gap-1 font-normal"><AlertCircle className="h-3 w-3" /> Error</Badge>;
}

function FileCard({
  row, folders, onOpen, onPreview, onDownload, onDelete, onReprocess, onShare, onRename, onMove,
}: {
  row: UploadRow; folders: Folder[];
  onOpen: () => void; onPreview: () => void; onDownload: () => void; onDelete: () => void;
  onReprocess: () => void; onShare: () => void; onRename: () => void; onMove: (id: string | null) => void;
}) {
  const Icon = iconFor(row.file_name);
  const title = row.title || row.file_name;
  return (
    <div className="glass card-hover rounded-3xl p-5 flex flex-col gap-3">
      <div className="flex items-start justify-between gap-2">
        <button onClick={onOpen} className="flex items-start gap-3 min-w-0 text-left flex-1">
          <div className="h-11 w-11 rounded-2xl gradient-bg flex items-center justify-center shrink-0 shadow-[var(--shadow-soft)]">
            <Icon className="h-5 w-5 text-white" />
          </div>
          <div className="min-w-0">
            <div className="font-semibold truncate">{title}</div>
            <div className="text-xs text-muted-foreground truncate">{row.file_name}</div>
          </div>
        </button>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="h-8 w-8 rounded-lg hover:bg-accent flex items-center justify-center text-muted-foreground shrink-0">
              <MoreHorizontal className="h-4 w-4" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-52">
            <DropdownMenuItem onClick={onPreview}><Eye className="h-4 w-4 mr-2" /> Preview</DropdownMenuItem>
            <DropdownMenuItem onClick={onOpen}><FileText className="h-4 w-4 mr-2" /> Open</DropdownMenuItem>
            <DropdownMenuItem onClick={onRename}><Pencil className="h-4 w-4 mr-2" /> Rename</DropdownMenuItem>
            <DropdownMenuSub>
              <DropdownMenuSubTrigger>
                <FolderInput className="h-4 w-4 mr-2" /> Move to…
              </DropdownMenuSubTrigger>
              <DropdownMenuSubContent>
                <DropdownMenuItem onClick={() => onMove(null)}>Unfiled</DropdownMenuItem>
                {folders.map((f) => (
                  <DropdownMenuItem key={f.id} onClick={() => onMove(f.id)}>{f.name}</DropdownMenuItem>
                ))}
              </DropdownMenuSubContent>
            </DropdownMenuSub>
            <DropdownMenuItem onClick={onDownload}><Download className="h-4 w-4 mr-2" /> Download</DropdownMenuItem>
            <DropdownMenuItem onClick={onShare}><Share2 className="h-4 w-4 mr-2" /> Share link</DropdownMenuItem>
            <DropdownMenuItem onClick={onReprocess}><RefreshCw className="h-4 w-4 mr-2" /> Reprocess with AI</DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={onDelete} className="text-destructive focus:text-destructive">
              <Trash2 className="h-4 w-4 mr-2" /> Delete
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <div className="flex items-center gap-2 flex-wrap">
        <StatusPill status={row.status} />
        {row.subject && <Badge variant="secondary" className="font-normal">{row.subject}</Badge>}
        {row.doc_type && <Badge variant="outline" className="font-normal capitalize">{row.doc_type.replace("_", " ")}</Badge>}
      </div>

      {row.tags?.length > 0 && (
        <div className="flex flex-wrap gap-1">
          {row.tags.slice(0, 4).map((t) => (
            <span key={t} className="text-[10px] uppercase tracking-wider text-muted-foreground bg-muted/60 px-2 py-0.5 rounded-full">
              {t}
            </span>
          ))}
        </div>
      )}

      {row.status === "error" && row.error && (
        <div className="text-xs text-destructive truncate">{row.error}</div>
      )}

      <div className="mt-auto pt-2 border-t border-border/60 flex items-center justify-between text-xs text-muted-foreground">
        <span>{formatSize(row.file_size)}</span>
        <span>Added {formatDate(row.created_at)}</span>
      </div>
      {row.last_opened_at && (
        <div className="text-[10px] text-muted-foreground -mt-1">Last opened {formatDate(row.last_opened_at)}</div>
      )}
    </div>
  );
}

function PreviewContent({ row, onDownload }: { row: UploadRow; onDownload: () => void }) {
  const a = row.analysis || {};
  return (
    <div className="space-y-6">
      <div>
        <DialogHeader>
          <DialogTitle className="text-2xl">{row.title || row.file_name}</DialogTitle>
        </DialogHeader>
        <div className="flex items-center gap-2 flex-wrap mt-2">
          <StatusPill status={row.status} />
          {row.subject && <Badge variant="secondary">{row.subject}</Badge>}
          {row.doc_type && <Badge variant="outline" className="capitalize">{row.doc_type.replace("_", " ")}</Badge>}
          <Button variant="ghost" size="sm" onClick={onDownload} className="ml-auto gap-1">
            <Download className="h-3.5 w-3.5" /> Download original
          </Button>
        </div>
      </div>

      {row.status !== "ready" && (
        <div className="glass rounded-2xl p-6 text-center text-muted-foreground">
          {row.status === "error" ? row.error : "Analyzing your document…"}
        </div>
      )}

      {row.status === "ready" && (
        <>
          {a.summary && (
            <Section title="Summary"><MarkdownMessage content={a.summary} /></Section>
          )}
          {Array.isArray(a.key_concepts) && a.key_concepts.length > 0 && (
            <Section title="Key concepts">
              <ul className="list-disc pl-5 space-y-1 text-sm">{a.key_concepts.map((x: string, i: number) => <li key={i}>{x}</li>)}</ul>
            </Section>
          )}
          {Array.isArray(a.vocabulary) && a.vocabulary.length > 0 && (
            <Section title="Vocabulary">
              <div className="grid sm:grid-cols-2 gap-2">
                {a.vocabulary.map((v: any, i: number) => (
                  <div key={i} className="rounded-xl bg-muted/40 p-3">
                    <div className="font-semibold text-sm">{v.term}</div>
                    <div className="text-xs text-muted-foreground">{v.definition}</div>
                  </div>
                ))}
              </div>
            </Section>
          )}
          {Array.isArray(a.formulas) && a.formulas.length > 0 && (
            <Section title="Formulas">
              <div className="space-y-1">{a.formulas.map((f: string, i: number) => <MarkdownMessage key={i} content={f} />)}</div>
            </Section>
          )}
          {Array.isArray(a.dates) && a.dates.length > 0 && (
            <Section title="Important dates">
              <ul className="list-disc pl-5 space-y-1 text-sm">{a.dates.map((x: string, i: number) => <li key={i}>{x}</li>)}</ul>
            </Section>
          )}
          {Array.isArray(a.outline) && a.outline.length > 0 && (
            <Section title="Outline">
              <ul className="list-disc pl-5 space-y-1 text-sm">{a.outline.map((x: string, i: number) => <li key={i}>{x}</li>)}</ul>
            </Section>
          )}
          {Array.isArray(a.questions) && a.questions.length > 0 && (
            <Section title="Questions found">
              <div className="space-y-2">
                {a.questions.map((q: any, i: number) => (
                  <div key={i} className="rounded-xl bg-muted/40 p-3">
                    <div className="font-medium text-sm">{i + 1}. {q.q}</div>
                    {q.a && <div className="text-xs text-muted-foreground mt-1">Answer: {q.a}</div>}
                  </div>
                ))}
              </div>
            </Section>
          )}
          {Array.isArray(a.flashcards) && a.flashcards.length > 0 && (
            <Section title="Flashcards">
              <div className="grid sm:grid-cols-2 gap-2">
                {a.flashcards.map((c: any, i: number) => (
                  <div key={i} className="rounded-xl border p-3 bg-card">
                    <div className="font-medium text-sm">{c.front}</div>
                    <div className="text-xs text-muted-foreground mt-1">{c.back}</div>
                  </div>
                ))}
              </div>
            </Section>
          )}
          {Array.isArray(a.practice_questions) && a.practice_questions.length > 0 && (
            <Section title="Practice questions">
              <div className="space-y-3">
                {a.practice_questions.map((q: any, i: number) => (
                  <div key={i} className="rounded-xl bg-muted/40 p-3">
                    <div className="font-medium text-sm">{i + 1}. {q.q}</div>
                    {Array.isArray(q.options) && (
                      <ul className="mt-2 text-xs space-y-0.5">
                        {q.options.map((o: string, j: number) => (
                          <li key={j} className={j === q.answer ? "text-success font-medium" : "text-muted-foreground"}>
                            {String.fromCharCode(65 + j)}. {o}
                          </li>
                        ))}
                      </ul>
                    )}
                    {q.explain && <div className="text-xs text-muted-foreground mt-1 italic">{q.explain}</div>}
                  </div>
                ))}
              </div>
            </Section>
          )}
        </>
      )}
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h3 className="text-xs uppercase tracking-[0.14em] text-primary font-medium mb-2">{title}</h3>
      {children}
    </div>
  );
}
