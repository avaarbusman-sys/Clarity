import { useEffect, useMemo, useState } from "react";
import { Navigate, useNavigate } from "react-router-dom";
import { Loader2, Sparkles, Check } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useProfile } from "@/hooks/useProfile";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import clarityLogo from "@/assets/clarity-logo.png.asset.json";

const GRADES = ["6th", "7th", "8th", "9th", "10th", "11th", "12th"];
const INTEREST_OPTIONS = [
  "Sports", "Basketball", "Soccer", "Football", "Video games", "Music",
  "Art", "Reading", "Movies", "Anime", "Cooking", "Baking", "Fashion",
  "Coding", "Space", "Animals", "Cars", "Dance", "Photography",
  "Nature", "Travel", "Skateboarding",
];

export default function Onboarding() {
  const { user, loading: authLoading } = useAuth();
  const { profile, loading: profileLoading, reload } = useProfile();
  const nav = useNavigate();

  const [displayName, setDisplayName] = useState("");
  const [grade, setGrade] = useState<string>("");
  const [birthday, setBirthday] = useState<string>("");
  const [interests, setInterests] = useState<string[]>([]);
  const [custom, setCustom] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (profile) {
      setDisplayName(profile.display_name ?? "");
      setGrade(profile.grade ?? "");
      setBirthday(profile.birthday ?? "");
      setInterests(profile.interests ?? []);
    }
  }, [profile]);

  const canSave = useMemo(
    () => displayName.trim() && grade && birthday && interests.length >= 1,
    [displayName, grade, birthday, interests],
  );

  if (authLoading || profileLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center text-muted-foreground">
        <Loader2 className="h-5 w-5 animate-spin" />
      </div>
    );
  }
  if (!user) return <Navigate to="/auth" replace />;
  if (profile?.onboarded) return <Navigate to="/dashboard" replace />;

  function toggle(tag: string) {
    setInterests((prev) => (prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]));
  }

  function addCustom() {
    const t = custom.trim();
    if (!t) return;
    if (!interests.includes(t)) setInterests([...interests, t]);
    setCustom("");
  }

  async function save() {
    if (!user || !canSave) return;
    setSaving(true);
    try {
      const { error } = await supabase
        .from("profiles")
        .upsert({
          id: user.id,
          display_name: displayName.trim(),
          grade,
          birthday,
          interests,
          onboarded: true,
        });
      if (error) throw error;
      await reload();
      toast.success("You're all set!");
      nav("/dashboard", { replace: true });
    } catch (err: any) {
      toast.error(err.message ?? "Couldn't save your profile");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        <div className="flex flex-col items-center mb-6">
          <img src={clarityLogo.url} alt="Clarity" className="h-14 w-14 rounded-2xl shadow-[var(--shadow-elegant)]" />
          <div className="mt-3 text-2xl font-semibold tracking-tight">Welcome to Clarity</div>
          <div className="text-xs text-muted-foreground">Let's personalize your study space</div>
        </div>

        <div className="glass rounded-3xl p-6 md:p-8 space-y-6">
          <div className="flex items-center gap-2 text-primary">
            <Sparkles className="h-4 w-4" />
            <span className="text-xs uppercase tracking-[0.14em] font-medium">A few quick questions</span>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Your name</label>
            <Input
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              placeholder="e.g. Ava"
              className="h-11 rounded-2xl"
            />
            <p className="text-xs text-muted-foreground">We'll use your first name to greet you.</p>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Grade</label>
            <div className="flex flex-wrap gap-2">
              {GRADES.map((g) => (
                <button
                  key={g}
                  type="button"
                  onClick={() => setGrade(g)}
                  className={`px-4 h-10 rounded-2xl border text-sm transition ${
                    grade === g
                      ? "border-primary bg-primary/10 text-primary"
                      : "border-border bg-background/60 hover:border-primary/50"
                  }`}
                >
                  {g}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Birthday</label>
            <Input
              type="date"
              value={birthday}
              onChange={(e) => setBirthday(e.target.value)}
              className="h-11 rounded-2xl max-w-xs"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Your interests</label>
            <p className="text-xs text-muted-foreground">
              Pick a few — Clarity will weave them into math word problems and English examples.
            </p>
            <div className="flex flex-wrap gap-2 pt-1">
              {INTEREST_OPTIONS.map((tag) => {
                const active = interests.includes(tag);
                return (
                  <button
                    key={tag}
                    type="button"
                    onClick={() => toggle(tag)}
                    className={`px-3 h-9 rounded-full border text-sm transition inline-flex items-center gap-1.5 ${
                      active
                        ? "border-primary bg-primary/10 text-primary"
                        : "border-border bg-background/60 hover:border-primary/50"
                    }`}
                  >
                    {active && <Check className="h-3.5 w-3.5" />}
                    {tag}
                  </button>
                );
              })}
            </div>
            <div className="flex gap-2 pt-2">
              <Input
                value={custom}
                onChange={(e) => setCustom(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), addCustom())}
                placeholder="Add your own..."
                className="h-10 rounded-2xl"
              />
              <Button type="button" variant="outline" onClick={addCustom} className="h-10 rounded-2xl">
                Add
              </Button>
            </div>
            {interests.filter((t) => !INTEREST_OPTIONS.includes(t)).length > 0 && (
              <div className="flex flex-wrap gap-2 pt-2">
                {interests
                  .filter((t) => !INTEREST_OPTIONS.includes(t))
                  .map((t) => (
                    <button
                      key={t}
                      type="button"
                      onClick={() => toggle(t)}
                      className="px-3 h-9 rounded-full border border-primary bg-primary/10 text-primary text-sm inline-flex items-center gap-1.5"
                    >
                      <Check className="h-3.5 w-3.5" />
                      {t}
                    </button>
                  ))}
              </div>
            )}
          </div>

          <Button
            onClick={save}
            disabled={!canSave || saving}
            className="w-full h-11 rounded-2xl gap-2"
          >
            {saving && <Loader2 className="h-4 w-4 animate-spin" />}
            Continue to Clarity
          </Button>
        </div>
      </div>
    </div>
  );
}
