import { useEffect, useRef, useState } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { Send, Sparkles, Loader2, Download } from "lucide-react";
import { MarkdownMessage } from "@/components/MarkdownMessage";
import { PageHeader } from "@/components/layout/PageHeader";
import { aiChat } from "@/lib/ai";
import { exportStudyGuideToPdf } from "@/lib/exportPdf";
import { toast } from "@/hooks/use-toast";


type Msg = { role: "user" | "assistant"; content: string };

const suggestions = [
  "Make a study guide on the American Revolution",
  "Explain the quadratic formula with examples",
  "Give me a study guide on cell biology",
  "Summarize the causes of World War II",
];

export default function StudyGuide() {
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [exporting, setExporting] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  async function downloadPdf() {
    if (exporting || !messages.length) return;
    setExporting(true);
    try {
      await exportStudyGuideToPdf(
        messages,
        (content) => renderToStaticMarkup(<MarkdownMessage content={content} />),
        `study-guide-${new Date().toISOString().slice(0, 10)}.pdf`,
      );
      toast({ title: "PDF downloaded", description: "Your study guide has been saved." });
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Failed to export";
      toast({ title: "Couldn't export PDF", description: msg, variant: "destructive" });
    } finally {
      setExporting(false);
    }
  }


  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, loading]);

  async function send(text: string) {
    const trimmed = text.trim();
    if (!trimmed || loading) return;
    const next: Msg[] = [...messages, { role: "user", content: trimmed }];
    setMessages(next);
    setInput("");
    setLoading(true);
    try {
      const reply = await aiChat("study-guide", next);
      setMessages([...next, { role: "assistant", content: reply }]);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Something went wrong";
      toast({ title: "Couldn't generate", description: msg, variant: "destructive" });
      setMessages(next);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="max-w-3xl mx-auto flex flex-col h-[calc(100vh-8rem)]">
      <PageHeader
        eyebrow="AI Study Guide"
        title="Ask for a guide on anything"
        description="Type any topic or question and Clarity will build you a study guide."
      />

      <div className="glass rounded-3xl flex-1 flex flex-col overflow-hidden relative">
        {messages.some((m) => m.role === "assistant") && (
          <button
            onClick={downloadPdf}
            disabled={exporting}
            title="Download as PDF"
            aria-label="Download as PDF"
            className="absolute top-3 right-3 z-10 inline-flex items-center gap-2 rounded-full px-3 py-1.5 bg-background/80 backdrop-blur border border-border hover:border-primary/50 hover:bg-accent/60 transition text-xs font-medium disabled:opacity-50 shadow-[var(--shadow-soft)]"
          >
            {exporting ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Download className="h-3.5 w-3.5" />}
            <span className="hidden sm:inline">{exporting ? "Preparing..." : "PDF"}</span>
          </button>
        )}
        <div ref={scrollRef} className="flex-1 overflow-y-auto p-5 md:p-6 space-y-4">
          {messages.length === 0 && !loading && (
            <div className="h-full flex flex-col items-center justify-center text-center py-10">
              <div className="h-14 w-14 rounded-2xl gradient-bg flex items-center justify-center shadow-[var(--shadow-elegant)]">
                <Sparkles className="h-6 w-6 text-primary-foreground" />
              </div>
              <p className="mt-4 text-muted-foreground max-w-sm">
                Ask about any topic — biology, algebra, essays, history. You'll get a clean, structured study guide.
              </p>
              <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-2 w-full max-w-lg">
                {suggestions.map((s) => (
                  <button
                    key={s}
                    onClick={() => send(s)}
                    className="text-left text-sm p-3 rounded-2xl bg-background/60 border border-border hover:border-primary/50 transition"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}

          {messages.map((m, i) => (
            <Bubble key={i} msg={m} />
          ))}
          {loading && <TypingBubble />}
        </div>

        <div className="border-t border-border/70 p-3 md:p-4">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              send(input);
            }}
            className="flex items-center gap-2 bg-background/70 rounded-2xl border border-border pl-4 pr-1.5 py-1.5"
          >
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask for a study guide on any topic..."
              disabled={loading}
              className="flex-1 bg-transparent outline-none text-sm py-2 placeholder:text-muted-foreground"
            />
            <button
              type="submit"
              disabled={loading || !input.trim()}
              className="h-9 w-9 rounded-xl gradient-bg text-primary-foreground flex items-center justify-center disabled:opacity-40 transition"
              aria-label="Send"
            >
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

function Bubble({ msg }: { msg: Msg }) {
  const isUser = msg.role === "user";
  return (
    <div className={`flex ${isUser ? "justify-end" : "justify-start"} animate-fade-in`}>
      {!isUser && (
        <div className="h-8 w-8 rounded-xl gradient-bg text-primary-foreground flex items-center justify-center mr-2 shrink-0">
          <Sparkles className="h-4 w-4" />
        </div>
      )}
      <div
        className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
          isUser
            ? "gradient-bg text-primary-foreground rounded-tr-md shadow-[var(--shadow-soft)]"
            : "bg-accent/60 text-foreground rounded-tl-md"
        }`}
      >
        {isUser ? (
          msg.content
        ) : (
          <MarkdownMessage content={msg.content} />
        )}
      </div>
    </div>
  );
}

function TypingBubble() {
  return (
    <div className="flex justify-start animate-fade-in">
      <div className="h-8 w-8 rounded-xl gradient-bg text-primary-foreground flex items-center justify-center mr-2 shrink-0">
        <Sparkles className="h-4 w-4" />
      </div>
      <div className="rounded-2xl rounded-tl-md bg-accent/60 px-4 py-3">
        <div className="flex items-center gap-1.5">
          {[0, 1, 2].map((i) => (
            <span
              key={i}
              className="h-1.5 w-1.5 rounded-full bg-primary/60 animate-pulse"
              style={{ animationDelay: `${i * 150}ms` }}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
