import { Link, useParams } from "react-router-dom";
import { ArrowLeft, BookOpen, Sparkles, Layers, Brain, MessageCircle } from "lucide-react";
import { subjects } from "@/data/subjects";
import { PageHeader } from "@/components/layout/PageHeader";

export default function SubjectDetail() {
  const { slug } = useParams();
  const subject = subjects.find((s) => s.slug === slug);

  if (!subject) {
    return (
      <div className="max-w-3xl mx-auto text-center py-24">
        <p className="text-muted-foreground">Subject not found.</p>
        <Link to="/subjects" className="text-primary underline mt-4 inline-block">
          Back to subjects
        </Link>
      </div>
    );
  }

  const tools = [
    { to: `/tutor?subject=${subject.slug}`, label: `${subject.name} Tutor`, icon: MessageCircle },
    { to: "/study-guide", label: "Study Guide", icon: Sparkles },
    { to: "/flashcards", label: "Flashcards", icon: Layers },
    { to: "/quiz", label: "Quiz", icon: Brain },
  ];

  return (
    <div className="max-w-6xl mx-auto">
      <Link
        to="/subjects"
        className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition mb-4"
      >
        <ArrowLeft className="h-4 w-4" /> All subjects
      </Link>

      <PageHeader eyebrow="Subject" title={subject.name} description={subject.tagline} />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5 mb-8">
        {tools.map(({ to, label, icon: Icon }) => (
          <Link
            key={to}
            to={to}
            className="glass rounded-2xl p-5 card-hover flex items-center gap-3"
          >
            <div className="h-10 w-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center">
              <Icon className="h-4.5 w-4.5" size={18} />
            </div>
            <div className="font-medium">{label}</div>
          </Link>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="glass rounded-3xl p-6">
          <h3 className="text-lg font-semibold tracking-tight mb-4">Key topics</h3>
          <div className="space-y-3">
            {subject.topics.map((t) => (
              <div key={t.title} className="p-4 rounded-2xl bg-accent/40 border border-border/60">
                <div className="font-medium">{t.title}</div>
                <p className="text-sm text-muted-foreground mt-1">{t.description}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="glass rounded-3xl p-6">
          <h3 className="text-lg font-semibold tracking-tight mb-4">Recommended reading</h3>
          <div className="space-y-3">
            {subject.reading.map((r) => (
              <div key={r.title} className="p-4 rounded-2xl bg-accent/40 border border-border/60">
                <div className="flex items-start gap-3">
                  <BookOpen className="h-4.5 w-4.5 text-primary mt-0.5" size={18} />
                  <div>
                    <div className="font-medium">{r.title}</div>
                    <p className="text-sm text-muted-foreground mt-1">{r.summary}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
