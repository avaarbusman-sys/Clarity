import { useMemo, useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { Plus, Search, CalendarDays, ChevronLeft, ChevronRight, AlertTriangle, Sparkles, Trash2 } from "lucide-react";
import { PageHeader } from "@/components/layout/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { cn } from "@/lib/utils";
import { usePlannerEvents, type PlannerEvent, type PlannerType } from "@/hooks/usePlannerEvents";
import {
  TYPE_META,
  SUBJECTS,
  ymd,
  fromYmd,
  todayYmd,
  isOverdue,
  formatTime,
  comparator,
  workloadLevel,
} from "@/lib/planner";
import { EventDialog } from "@/components/planner/EventDialog";
import { EventCard } from "@/components/planner/EventCard";
import { toast } from "@/hooks/use-toast";

type View = "month" | "week" | "day";
type StatusFilter = "all" | "upcoming" | "completed" | "overdue";
type SortKey = "due" | "priority";

export default function Planner() {
  const [params, setParams] = useSearchParams();
  const { events, create, update, remove, duplicate, toggleComplete, move, clearAll } = usePlannerEvents();

  const [view, setView] = useState<View>("month");
  const [cursor, setCursor] = useState<Date>(new Date());
  const [selectedDate, setSelectedDate] = useState<string>(todayYmd());
  const [query, setQuery] = useState("");
  const [subjectFilter, setSubjectFilter] = useState<string>("all");
  const [typeFilter, setTypeFilter] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all");
  const [sort, setSort] = useState<SortKey>("due");

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<PlannerEvent | null>(null);
  const [defaultDate, setDefaultDate] = useState<string | undefined>();

  // Open event from URL (?event=<id>)
  useEffect(() => {
    const id = params.get("event");
    if (!id || !events.length) return;
    const ev = events.find((e) => e.id === id);
    if (ev) {
      setSelectedDate(ev.due_date);
      setEditing(ev);
      setDialogOpen(true);
      params.delete("event");
      setParams(params, { replace: true });
    }
  }, [params, events, setParams]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return events.filter((e) => {
      if (subjectFilter !== "all" && e.subject !== subjectFilter) return false;
      if (typeFilter !== "all" && e.type !== typeFilter) return false;
      if (statusFilter === "upcoming" && (e.status !== "pending" || isOverdue(e))) return false;
      if (statusFilter === "completed" && e.status === "pending") return false;
      if (statusFilter === "overdue" && !isOverdue(e)) return false;
      if (q) {
        const hay = `${e.title} ${e.subject ?? ""} ${e.description ?? ""}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    }).sort(comparator(sort));
  }, [events, query, subjectFilter, typeFilter, statusFilter, sort]);

  const eventsByDate = useMemo(() => {
    const map = new Map<string, PlannerEvent[]>();
    for (const e of filtered) {
      const arr = map.get(e.due_date) ?? [];
      arr.push(e);
      map.set(e.due_date, arr);
    }
    return map;
  }, [filtered]);

  const today = todayYmd();
  const overdueEvents = events.filter(isOverdue);
  const todayEvents = filtered.filter((e) => e.due_date === today);

  const weekStart = new Date();
  weekStart.setHours(0, 0, 0, 0);
  const weekEnd = new Date(weekStart);
  weekEnd.setDate(weekEnd.getDate() + 7);
  const weekEvents = filtered.filter((e) => {
    const d = fromYmd(e.due_date);
    return d >= weekStart && d < weekEnd && e.status === "pending";
  });
  const workload = workloadLevel(weekEvents.length);

  const upcoming = filtered
    .filter((e) => e.status === "pending" && e.due_date >= today)
    .slice(0, 8);

  function openCreate(date?: string) {
    setEditing(null);
    setDefaultDate(date);
    setDialogOpen(true);
  }

  function openEdit(e: PlannerEvent) {
    setEditing(e);
    setDefaultDate(undefined);
    setDialogOpen(true);
  }

  async function handleSave(input: Parameters<typeof create>[0], id?: string) {
    if (id) {
      await update(id, input);
      toast({ title: "Event updated" });
    } else {
      await create(input);
      toast({ title: "Event created" });
    }
  }

  async function handleDelete(e: PlannerEvent) {
    await remove(e.id);
    toast({ title: "Event deleted" });
  }

  return (
    <div className="max-w-7xl mx-auto pb-24">
      <PageHeader
        eyebrow="Planner"
        title="Plan every assignment, quiz, and study session."
        description="A calm home for your deadlines — organized, searchable, and always in sync."
      />

      {/* Toolbar */}
      <div className="glass rounded-3xl p-4 md:p-5 mb-6 flex flex-col lg:flex-row gap-3 lg:items-center lg:justify-between">
        <div className="flex flex-1 items-center gap-2 min-w-0">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search events"
              className="pl-9"
            />
          </div>
          <Tabs value={view} onValueChange={(v) => setView(v as View)}>
            <TabsList>
              <TabsTrigger value="month">Month</TabsTrigger>
              <TabsTrigger value="week">Week</TabsTrigger>
              <TabsTrigger value="day">Day</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        <div className="flex flex-wrap gap-2 items-center">
          <Select value={subjectFilter} onValueChange={setSubjectFilter}>
            <SelectTrigger className="w-[130px]"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All subjects</SelectItem>
              {SUBJECTS.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-[130px]"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All types</SelectItem>
              {(Object.keys(TYPE_META) as PlannerType[]).map((t) => (
                <SelectItem key={t} value={t}>{TYPE_META[t].emoji} {TYPE_META[t].label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as StatusFilter)}>
            <SelectTrigger className="w-[130px]"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All statuses</SelectItem>
              <SelectItem value="upcoming">Upcoming</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="overdue">Overdue</SelectItem>
            </SelectContent>
          </Select>
          <Select value={sort} onValueChange={(v) => setSort(v as SortKey)}>
            <SelectTrigger className="w-[130px]"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="due">Sort: Due date</SelectItem>
              <SelectItem value="priority">Sort: Priority</SelectItem>
            </SelectContent>
          </Select>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button
                variant="outline"
                size="sm"
                disabled={events.length === 0}
                className="text-destructive hover:text-destructive"
              >
                <Trash2 className="h-4 w-4 mr-1.5" />
                Clear all
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Clear all assignments?</AlertDialogTitle>
                <AlertDialogDescription>
                  This will permanently delete all {events.length} planner {events.length === 1 ? "event" : "events"} — assignments, quizzes, tests, and study sessions. This cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction
                  onClick={async () => {
                    await clearAll();
                    toast({ title: "All events cleared" });
                  }}
                  className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                >
                  Delete all
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>

      {overdueEvents.length > 0 && (
        <div className="mb-6 glass rounded-2xl p-4 border border-destructive/30 flex items-start gap-3">
          <div className="h-9 w-9 rounded-xl bg-destructive/10 text-destructive flex items-center justify-center">
            <AlertTriangle className="h-4 w-4" />
          </div>
          <div className="flex-1">
            <div className="font-semibold text-sm">You have {overdueEvents.length} overdue {overdueEvents.length === 1 ? "item" : "items"}</div>
            <div className="text-xs text-muted-foreground">Catch up when you can — they'll stay pinned here until done.</div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-6">
        <div>
          {view === "month" && (
            <MonthView
              cursor={cursor}
              setCursor={setCursor}
              eventsByDate={eventsByDate}
              onDayClick={(d) => { setSelectedDate(d); setView("day"); }}
              onDayAdd={(d) => openCreate(d)}
              onDrop={move}
              selectedDate={selectedDate}
            />
          )}
          {view === "week" && (
            <WeekView
              cursor={cursor}
              setCursor={setCursor}
              eventsByDate={eventsByDate}
              onEdit={openEdit}
              onDelete={handleDelete}
              onDuplicate={duplicate}
              onToggle={toggleComplete}
              onAdd={openCreate}
            />
          )}
          {view === "day" && (
            <DayView
              date={selectedDate}
              setDate={setSelectedDate}
              events={eventsByDate.get(selectedDate) ?? []}
              onEdit={openEdit}
              onDelete={handleDelete}
              onDuplicate={duplicate}
              onToggle={toggleComplete}
              onAdd={() => openCreate(selectedDate)}
            />
          )}
        </div>

        {/* Right rail */}
        <aside className="space-y-4">
          <div className="glass rounded-3xl p-5">
            <div className="flex items-center justify-between mb-2">
              <div className="text-xs uppercase tracking-[0.14em] text-primary font-medium">This week</div>
              <span className={cn("text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-full border font-medium", workload.className)}>
                {workload.label} load
              </span>
            </div>
            <div className="text-2xl font-semibold">{weekEvents.length} <span className="text-sm font-normal text-muted-foreground">pending</span></div>
          </div>

          <div className="glass rounded-3xl p-5">
            <div className="text-xs uppercase tracking-[0.14em] text-primary font-medium mb-3">Today's tasks</div>
            {todayEvents.length === 0 ? (
              <p className="text-sm text-muted-foreground">Nothing due today. Enjoy the calm.</p>
            ) : (
              <div className="space-y-2">
                {todayEvents.map((e) => (
                  <EventCard
                    key={e.id}
                    event={e}
                    onEdit={openEdit}
                    onDelete={handleDelete}
                    onDuplicate={duplicate}
                    onToggle={toggleComplete}
                  />
                ))}
              </div>
            )}
          </div>

          <div className="glass rounded-3xl p-5">
            <div className="text-xs uppercase tracking-[0.14em] text-primary font-medium mb-3">Upcoming</div>
            {upcoming.length === 0 ? (
              <p className="text-sm text-muted-foreground">No upcoming events yet.</p>
            ) : (
              <div className="space-y-2">
                {upcoming.map((e) => (
                  <EventCard
                    key={e.id}
                    event={e}
                    onEdit={openEdit}
                    onDelete={handleDelete}
                    onDuplicate={duplicate}
                    onToggle={toggleComplete}
                    showDate
                  />
                ))}
              </div>
            )}
          </div>

          <div className="glass rounded-3xl p-5 bg-gradient-to-br from-primary/5 to-primary-glow/5">
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="h-4 w-4 text-primary" />
              <div className="text-sm font-semibold">Smart tip</div>
            </div>
            <p className="text-xs text-muted-foreground">
              Ask the AI Tutor to "create a study schedule for my next test" — it'll use these events to build one.
            </p>
          </div>
        </aside>
      </div>

      {/* Floating add */}
      <button
        onClick={() => openCreate()}
        className="fixed bottom-6 right-6 z-30 h-14 w-14 rounded-full gradient-bg text-primary-foreground shadow-[var(--shadow-elegant)] flex items-center justify-center hover:scale-105 transition-transform"
        aria-label="Add event"
      >
        <Plus className="h-6 w-6" />
      </button>

      <EventDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        initial={editing}
        defaultDate={defaultDate}
        onSave={handleSave}
        events={events}
      />
    </div>
  );
}

/* ---------------- Month view ---------------- */

function MonthView({
  cursor,
  setCursor,
  eventsByDate,
  onDayClick,
  onDayAdd,
  onDrop,
  selectedDate,
}: {
  cursor: Date;
  setCursor: (d: Date) => void;
  eventsByDate: Map<string, PlannerEvent[]>;
  onDayClick: (d: string) => void;
  onDayAdd: (d: string) => void;
  onDrop: (id: string, newDate: string) => void;
  selectedDate: string;
}) {
  const year = cursor.getFullYear();
  const month = cursor.getMonth();
  const first = new Date(year, month, 1);
  const startWeekday = first.getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const cells: (Date | null)[] = [];
  for (let i = 0; i < startWeekday; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(new Date(year, month, d));
  while (cells.length % 7 !== 0) cells.push(null);

  const today = todayYmd();
  const monthLabel = cursor.toLocaleDateString(undefined, { month: "long", year: "numeric" });
  const weekdays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

  return (
    <div className="glass rounded-3xl p-4 md:p-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <CalendarDays className="h-5 w-5 text-primary" />
          <h3 className="text-lg font-semibold tracking-tight">{monthLabel}</h3>
        </div>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="icon" onClick={() => setCursor(new Date(year, month - 1, 1))}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={() => setCursor(new Date())}>Today</Button>
          <Button variant="ghost" size="icon" onClick={() => setCursor(new Date(year, month + 1, 1))}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-7 gap-1 text-xs text-muted-foreground mb-1 px-1">
        {weekdays.map((w) => <div key={w} className="py-1 text-center font-medium">{w}</div>)}
      </div>

      <div className="grid grid-cols-7 gap-1">
        {cells.map((d, i) => {
          if (!d) return <div key={i} className="aspect-square" />;
          const key = ymd(d);
          const events = eventsByDate.get(key) ?? [];
          const isToday = key === today;
          const isSelected = key === selectedDate;
          return (
            <button
              key={i}
              onClick={() => onDayClick(key)}
              onDoubleClick={() => onDayAdd(key)}
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault();
                const id = e.dataTransfer.getData("text/plain");
                if (id) onDrop(id, key);
              }}
              className={cn(
                "aspect-square min-h-[64px] rounded-xl border border-transparent p-1.5 text-left transition-all",
                "hover:bg-accent/40 hover:border-border",
                isToday && "bg-primary/5 border-primary/30",
                isSelected && "ring-2 ring-primary/40",
              )}
            >
              <div className={cn("text-xs font-medium mb-1", isToday && "text-primary")}>{d.getDate()}</div>
              <div className="flex flex-wrap gap-0.5">
                {events.slice(0, 4).map((e) => {
                  const meta = TYPE_META[e.type];
                  return (
                    <span
                      key={e.id}
                      title={`${meta.emoji} ${e.title}`}
                      className={cn("h-1.5 w-1.5 rounded-full", meta.dot, e.status !== "pending" && "opacity-40")}
                    />
                  );
                })}
                {events.length > 4 && (
                  <span className="text-[9px] text-muted-foreground leading-none">+{events.length - 4}</span>
                )}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

/* ---------------- Week view ---------------- */

function WeekView({
  cursor,
  setCursor,
  eventsByDate,
  onEdit,
  onDelete,
  onDuplicate,
  onToggle,
  onAdd,
}: {
  cursor: Date;
  setCursor: (d: Date) => void;
  eventsByDate: Map<string, PlannerEvent[]>;
  onEdit: (e: PlannerEvent) => void;
  onDelete: (e: PlannerEvent) => void;
  onDuplicate: (e: PlannerEvent) => void;
  onToggle: (e: PlannerEvent) => void;
  onAdd: (d: string) => void;
}) {
  const start = new Date(cursor);
  start.setDate(start.getDate() - start.getDay());
  start.setHours(0, 0, 0, 0);
  const days = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(start);
    d.setDate(start.getDate() + i);
    return d;
  });
  const end = new Date(start);
  end.setDate(end.getDate() + 6);
  const rangeLabel = `${start.toLocaleDateString(undefined, { month: "short", day: "numeric" })} – ${end.toLocaleDateString(undefined, { month: "short", day: "numeric" })}`;
  const today = todayYmd();

  return (
    <div className="glass rounded-3xl p-4 md:p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold tracking-tight">{rangeLabel}</h3>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="icon" onClick={() => { const n = new Date(cursor); n.setDate(n.getDate() - 7); setCursor(n); }}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={() => setCursor(new Date())}>This week</Button>
          <Button variant="ghost" size="icon" onClick={() => { const n = new Date(cursor); n.setDate(n.getDate() + 7); setCursor(n); }}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>
      <div className="space-y-4">
        {days.map((d) => {
          const key = ymd(d);
          const events = eventsByDate.get(key) ?? [];
          const isToday = key === today;
          return (
            <div key={key}>
              <div className="flex items-center justify-between mb-2">
                <div className={cn("text-sm font-semibold", isToday && "text-primary")}>
                  {d.toLocaleDateString(undefined, { weekday: "long" })}
                  <span className="ml-2 text-muted-foreground font-normal">
                    {d.toLocaleDateString(undefined, { month: "short", day: "numeric" })}
                  </span>
                </div>
                <Button variant="ghost" size="sm" onClick={() => onAdd(key)}>
                  <Plus className="h-3.5 w-3.5 mr-1" /> Add
                </Button>
              </div>
              {events.length === 0 ? (
                <div className="text-xs text-muted-foreground pl-1 pb-2 border-l-2 border-border ml-1">No events</div>
              ) : (
                <div className="space-y-2">
                  {events.map((e) => (
                    <EventCard key={e.id} event={e} onEdit={onEdit} onDelete={onDelete} onDuplicate={onDuplicate} onToggle={onToggle} draggable />
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ---------------- Day view ---------------- */

function DayView({
  date,
  setDate,
  events,
  onEdit,
  onDelete,
  onDuplicate,
  onToggle,
  onAdd,
}: {
  date: string;
  setDate: (d: string) => void;
  events: PlannerEvent[];
  onEdit: (e: PlannerEvent) => void;
  onDelete: (e: PlannerEvent) => void;
  onDuplicate: (e: PlannerEvent) => void;
  onToggle: (e: PlannerEvent) => void;
  onAdd: () => void;
}) {
  const d = fromYmd(date);
  const label = d.toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" });
  const timed = events.filter((e) => e.due_time).sort((a, b) => (a.due_time ?? "").localeCompare(b.due_time ?? ""));
  const untimed = events.filter((e) => !e.due_time);
  return (
    <div className="glass rounded-3xl p-4 md:p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold tracking-tight">{label}</h3>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="icon" onClick={() => { const n = new Date(d); n.setDate(n.getDate() - 1); setDate(ymd(n)); }}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={() => setDate(todayYmd())}>Today</Button>
          <Button variant="ghost" size="icon" onClick={() => { const n = new Date(d); n.setDate(n.getDate() + 1); setDate(ymd(n)); }}>
            <ChevronRight className="h-4 w-4" />
          </Button>
          <Button size="sm" onClick={onAdd} className="ml-2">
            <Plus className="h-3.5 w-3.5 mr-1" /> Add
          </Button>
        </div>
      </div>
      {events.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-border/70 p-8 text-center text-sm text-muted-foreground">
          Nothing scheduled for this day.
        </div>
      ) : (
        <div className="space-y-4">
          {timed.length > 0 && (
            <div className="space-y-2">
              {timed.map((e) => (
                <div key={e.id} className="flex gap-3">
                  <div className="w-16 pt-3 text-xs text-muted-foreground tabular-nums">{formatTime(e.due_time)}</div>
                  <div className="flex-1">
                    <EventCard event={e} onEdit={onEdit} onDelete={onDelete} onDuplicate={onDuplicate} onToggle={onToggle} />
                  </div>
                </div>
              ))}
            </div>
          )}
          {untimed.length > 0 && (
            <div>
              {timed.length > 0 && <div className="text-xs uppercase tracking-[0.14em] text-muted-foreground mb-2">All day</div>}
              <div className="space-y-2">
                {untimed.map((e) => (
                  <EventCard key={e.id} event={e} onEdit={onEdit} onDelete={onDelete} onDuplicate={onDuplicate} onToggle={onToggle} />
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
