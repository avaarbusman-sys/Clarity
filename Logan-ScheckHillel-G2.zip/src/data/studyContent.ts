import { subjects } from "./subjects";

export const subjectSlugs = ["math", "science", "english", "history"] as const;
export type SubjectSlug = (typeof subjectSlugs)[number];

export const subjectNames: Record<SubjectSlug, string> = {
  math: "Math",
  science: "Science",
  english: "English",
  history: "History",
};

export { subjects };

// ============ FLASHCARDS ============
export const flashcardsBySubject: Record<SubjectSlug, { front: string; back: string }[]> = {
  math: [
    { front: "What does slope mean in y = mx + b?", back: "The rate of change of y with respect to x. 'm' is the slope." },
    { front: "Pythagorean theorem?", back: "In a right triangle, a² + b² = c², where c is the hypotenuse." },
    { front: "Quadratic formula?", back: "x = (−b ± √(b² − 4ac)) / (2a) for ax² + bx + c = 0." },
    { front: "What is the discriminant?", back: "b² − 4ac — tells how many real solutions a quadratic has." },
    { front: "Area of a circle?", back: "A = πr², where r is the radius." },
    { front: "Slope-intercept form?", back: "y = mx + b, where m is slope and b is y-intercept." },
    { front: "What is a function?", back: "A relation where every input has exactly one output." },
    { front: "Probability of independent events A and B?", back: "P(A and B) = P(A) × P(B)." },
  ],
  science: [
    { front: "What is photosynthesis?", back: "The process plants use to convert sunlight, water, and CO₂ into glucose and oxygen." },
    { front: "Newton's Second Law?", back: "Force equals mass times acceleration (F = ma)." },
    { front: "What is the mitochondrion?", back: "The organelle that produces ATP through cellular respiration — the 'powerhouse of the cell'." },
    { front: "Ionic vs covalent bonds?", back: "Ionic bonds transfer electrons; covalent bonds share them." },
    { front: "What is an ecosystem?", back: "A community of living organisms interacting with their physical environment." },
    { front: "Three states of matter?", back: "Solid, liquid, and gas (plasma is a fourth)." },
    { front: "Newton's Third Law?", back: "For every action there is an equal and opposite reaction." },
    { front: "What does DNA stand for?", back: "Deoxyribonucleic acid — carries genetic instructions." },
  ],
  english: [
    { front: "What is a metaphor?", back: "A direct comparison of two unlike things without using 'like' or 'as'." },
    { front: "What is a simile?", back: "A comparison using 'like' or 'as'." },
    { front: "Who wrote 'Romeo and Juliet'?", back: "William Shakespeare, first published around 1597." },
    { front: "What is a thesis statement?", back: "A single sentence that states the main argument of an essay." },
    { front: "What is foreshadowing?", back: "Hints or clues about events that will happen later in the story." },
    { front: "What is alliteration?", back: "Repetition of the same consonant sound at the start of nearby words." },
    { front: "What is an independent clause?", back: "A group of words with a subject and verb that can stand alone as a sentence." },
    { front: "What is tone?", back: "The author's attitude toward the subject, revealed through word choice." },
  ],
  history: [
    { front: "When did WWII end?", back: "1945, with the surrender of Japan in September." },
    { front: "What was the Industrial Revolution?", back: "A period (late 1700s–1800s) of rapid industrial and technological change beginning in Britain." },
    { front: "Who wrote the Declaration of Independence?", back: "Primarily Thomas Jefferson, adopted July 4, 1776." },
    { front: "What was the Civil Rights Movement?", back: "A 1950s–60s struggle to end racial segregation and discrimination in the U.S." },
    { front: "What caused WWI?", back: "The assassination of Archduke Franz Ferdinand triggered a web of alliances into war." },
    { front: "What is the Magna Carta?", back: "A 1215 English charter limiting the king's power — a foundation of modern law." },
    { front: "What was the Cold War?", back: "Post-WWII tension between the U.S. and Soviet Union (roughly 1947–1991)." },
    { front: "Who was Martin Luther King Jr.?", back: "A leader of the American Civil Rights Movement known for nonviolent activism." },
  ],
};

// ============ QUIZ ============
export interface QuizQuestion {
  q: string;
  options: string[];
  answer: number;
  explain: string;
}

export const quizBySubject: Record<SubjectSlug, QuizQuestion[]> = {
  math: [
    { q: "Solve for x: 2x + 6 = 20", options: ["5", "6", "7", "8"], answer: 2, explain: "2x = 14, so x = 7." },
    { q: "What is the slope of y = 3x + 5?", options: ["5", "3", "-3", "1/3"], answer: 1, explain: "In y = mx + b, the slope m is 3." },
    { q: "In a right triangle, if a=3 and b=4, what is c?", options: ["5", "6", "7", "12"], answer: 0, explain: "3² + 4² = 9+16 = 25, so c = 5." },
    { q: "What is the discriminant of x² − 4x + 4?", options: ["0", "4", "8", "16"], answer: 0, explain: "b² − 4ac = 16 − 16 = 0 — one real solution." },
    { q: "Area of a circle with r = 2?", options: ["2π", "4π", "8π", "16π"], answer: 1, explain: "A = πr² = π(2)² = 4π." },
  ],
  science: [
    { q: "Which organelle is the primary site of photosynthesis?", options: ["Mitochondrion", "Chloroplast", "Ribosome", "Nucleus"], answer: 1, explain: "Chloroplasts contain chlorophyll and carry out photosynthesis." },
    { q: "Newton's Second Law is best expressed as:", options: ["E = mc²", "F = ma", "V = IR", "PV = nRT"], answer: 1, explain: "Force equals mass times acceleration." },
    { q: "Water is made of which atoms?", options: ["2 H, 1 O", "1 H, 2 O", "2 H, 2 O", "1 H, 1 O"], answer: 0, explain: "H₂O — two hydrogen, one oxygen." },
    { q: "Which bond shares electrons?", options: ["Ionic", "Covalent", "Metallic", "Hydrogen"], answer: 1, explain: "Covalent bonds share electron pairs." },
    { q: "What produces ATP in a cell?", options: ["Nucleus", "Ribosome", "Mitochondrion", "Chloroplast"], answer: 2, explain: "The mitochondrion is the site of cellular respiration and ATP production." },
  ],
  english: [
    { q: "Which device compares two things using 'like' or 'as'?", options: ["Metaphor", "Simile", "Alliteration", "Hyperbole"], answer: 1, explain: "A simile uses 'like' or 'as' to draw a comparison." },
    { q: "Who wrote 'Hamlet'?", options: ["Dickens", "Shakespeare", "Austen", "Hemingway"], answer: 1, explain: "William Shakespeare wrote Hamlet around 1600." },
    { q: "The main argument of an essay is the:", options: ["Hook", "Thesis", "Conclusion", "Citation"], answer: 1, explain: "The thesis statement expresses the main argument." },
    { q: "Which is an independent clause?", options: ["After I ate", "Because it rained", "She went home", "Running fast"], answer: 2, explain: "'She went home' has subject + verb and stands alone." },
    { q: "'Peter Piper picked' is an example of:", options: ["Metaphor", "Alliteration", "Irony", "Rhyme"], answer: 1, explain: "Repetition of the 'p' sound is alliteration." },
  ],
  history: [
    { q: "In what year did World War II end?", options: ["1943", "1945", "1947", "1950"], answer: 1, explain: "World War II ended in 1945." },
    { q: "The Industrial Revolution began in:", options: ["France", "Britain", "Germany", "USA"], answer: 1, explain: "It began in Britain in the late 1700s." },
    { q: "Who primarily wrote the Declaration of Independence?", options: ["Franklin", "Washington", "Jefferson", "Adams"], answer: 2, explain: "Thomas Jefferson was the principal author." },
    { q: "The Cold War was primarily between the U.S. and:", options: ["China", "Germany", "Soviet Union", "Japan"], answer: 2, explain: "It was a rivalry between the U.S. and the Soviet Union." },
    { q: "The Magna Carta was signed in:", options: ["1066", "1215", "1492", "1776"], answer: 1, explain: "The Magna Carta was signed in 1215." },
  ],
};

// ============ STUDY GUIDES (mock AI responses per topic) ============
export interface StudyGuide {
  topic: string;
  summary: string;
  keyConcepts: string[];
  vocabulary: [string, string][];
  facts: string[];
  practice: string[];
}

export const studyGuideBank: { keywords: string[]; guide: StudyGuide }[] = [
  {
    keywords: ["photosynthesis", "plant", "chloroplast"],
    guide: {
      topic: "Photosynthesis",
      summary: "Photosynthesis is how plants convert sunlight, water, and CO₂ into glucose and oxygen. It has two stages — light-dependent reactions and the Calvin cycle — both happening inside chloroplasts.",
      keyConcepts: [
        "Light-dependent reactions occur in the thylakoid membranes and produce ATP and NADPH.",
        "The Calvin cycle takes place in the stroma and uses ATP/NADPH to fix CO₂ into glucose.",
        "Chlorophyll absorbs light most strongly in red and blue wavelengths.",
        "Cellular respiration is essentially the reverse process.",
      ],
      vocabulary: [
        ["Chloroplast", "Organelle where photosynthesis takes place."],
        ["ATP", "Molecule that stores and transfers energy in cells."],
        ["Stroma", "Fluid inside the chloroplast where the Calvin cycle occurs."],
        ["Chlorophyll", "Green pigment that absorbs light energy."],
      ],
      facts: [
        "The overall equation: 6CO₂ + 6H₂O → C₆H₁₂O₆ + 6O₂.",
        "Oxygen is released as a byproduct of splitting water.",
        "Photosynthesis is the foundation of most food chains.",
      ],
      practice: [
        "Where in the chloroplast do the light-dependent reactions occur?",
        "Name two products of the light-dependent reactions.",
        "Describe the purpose of the Calvin cycle in one sentence.",
      ],
    },
  },
  {
    keywords: ["quadratic", "quadratics", "parabola", "discriminant"],
    guide: {
      topic: "Quadratic Equations",
      summary: "A quadratic equation has the form ax² + bx + c = 0. You can solve it by factoring, completing the square, or using the quadratic formula. The graph is a parabola.",
      keyConcepts: [
        "The quadratic formula: x = (−b ± √(b² − 4ac)) / (2a).",
        "The discriminant b² − 4ac tells you how many real roots exist.",
        "A positive leading coefficient (a > 0) makes the parabola open upward.",
        "The vertex form y = a(x − h)² + k reveals the vertex directly.",
      ],
      vocabulary: [
        ["Discriminant", "The expression b² − 4ac inside the square root."],
        ["Vertex", "The highest or lowest point on the parabola."],
        ["Root", "A value of x that makes the equation equal to zero."],
        ["Coefficient", "A number multiplied by a variable."],
      ],
      facts: [
        "If the discriminant is 0, there is exactly one real solution.",
        "A parabola is symmetric across a vertical line through its vertex.",
        "Factoring works quickly when roots are integers.",
      ],
      practice: [
        "Solve x² − 5x + 6 = 0 by factoring.",
        "Find the discriminant of 2x² + 3x − 2.",
        "Rewrite y = x² − 6x + 5 in vertex form.",
      ],
    },
  },
  {
    keywords: ["linear", "slope", "y = mx", "line", "graph"],
    guide: {
      topic: "Linear Equations",
      summary: "A linear equation graphs as a straight line. Slope-intercept form (y = mx + b) makes slope and y-intercept easy to read.",
      keyConcepts: [
        "Slope m is rise over run — how much y changes per unit of x.",
        "The y-intercept b is where the line crosses the y-axis.",
        "Parallel lines share the same slope; perpendicular slopes are negative reciprocals.",
        "Point-slope form: y − y₁ = m(x − x₁).",
      ],
      vocabulary: [
        ["Slope", "Rate of change of y with respect to x."],
        ["Intercept", "Where a line crosses an axis."],
        ["Linear", "A relationship that graphs as a straight line."],
      ],
      facts: [
        "Two points uniquely define a line.",
        "Horizontal lines have slope 0; vertical lines have undefined slope.",
      ],
      practice: [
        "Find the slope between (2, 3) and (6, 11).",
        "Write the equation of a line with slope 2 through (0, −1).",
        "Are y = 2x + 3 and y = −½x + 1 perpendicular?",
      ],
    },
  },
  {
    keywords: ["newton", "force", "motion", "physics", "acceleration"],
    guide: {
      topic: "Newton's Laws of Motion",
      summary: "Newton's three laws describe how forces affect motion. Together they explain everything from a rolling ball to a rocket launch.",
      keyConcepts: [
        "First law: an object at rest stays at rest unless acted on by a net force.",
        "Second law: F = ma — force equals mass times acceleration.",
        "Third law: every action has an equal and opposite reaction.",
        "Net force is the vector sum of all forces on an object.",
      ],
      vocabulary: [
        ["Force", "A push or pull, measured in newtons."],
        ["Mass", "How much matter is in an object."],
        ["Acceleration", "The rate at which velocity changes."],
        ["Inertia", "An object's resistance to changes in motion."],
      ],
      facts: [
        "One newton = 1 kg·m/s².",
        "Weight is a force: W = mg.",
      ],
      practice: [
        "What net force is needed to accelerate a 5 kg object at 3 m/s²?",
        "Give an example of Newton's third law in daily life.",
        "Explain why passengers lurch forward when a car brakes.",
      ],
    },
  },
  {
    keywords: ["cell", "biology", "mitochondria", "organelle"],
    guide: {
      topic: "Cell Biology",
      summary: "Cells are the basic units of life. They contain specialized organelles that carry out functions like producing energy, storing DNA, and building proteins.",
      keyConcepts: [
        "The nucleus contains DNA and directs cell activity.",
        "Mitochondria produce ATP through cellular respiration.",
        "Ribosomes build proteins from amino acids.",
        "The cell membrane controls what enters and leaves the cell.",
      ],
      vocabulary: [
        ["Organelle", "A specialized structure inside a cell."],
        ["ATP", "The cell's main energy currency."],
        ["Cytoplasm", "Fluid inside the cell where organelles float."],
      ],
      facts: [
        "Prokaryotic cells (like bacteria) have no nucleus; eukaryotic cells do.",
        "Plant cells also have chloroplasts and a cell wall.",
      ],
      practice: [
        "Name three organelles found in a eukaryotic cell.",
        "What is the role of ribosomes?",
        "How does the cell membrane help maintain homeostasis?",
      ],
    },
  },
  {
    keywords: ["metaphor", "simile", "literary", "device", "figurative"],
    guide: {
      topic: "Literary Devices",
      summary: "Literary devices are tools writers use to create meaning, mood, and imagery. Recognizing them helps you analyze how a text works.",
      keyConcepts: [
        "Metaphor: a direct comparison ('Time is a thief').",
        "Simile: comparison using 'like' or 'as' ('brave as a lion').",
        "Personification: giving human traits to non-human things.",
        "Foreshadowing: hints about later events.",
      ],
      vocabulary: [
        ["Imagery", "Descriptive language that appeals to the senses."],
        ["Symbol", "An object that represents a larger idea."],
        ["Tone", "The author's attitude toward the subject."],
      ],
      facts: [
        "Devices often work together — a single line can hold imagery, tone, and metaphor.",
      ],
      practice: [
        "Identify the device: 'The wind whispered through the trees.'",
        "Write one metaphor and one simile about the ocean.",
        "How does foreshadowing build tension in a story?",
      ],
    },
  },
  {
    keywords: ["essay", "thesis", "writing", "argument"],
    guide: {
      topic: "Essay Structure",
      summary: "A strong essay has a clear thesis, organized evidence, and a conclusion that ties everything together.",
      keyConcepts: [
        "Introduction: hook, context, and thesis statement.",
        "Body paragraphs: one main idea each, with evidence and analysis.",
        "Conclusion: restate the thesis and reflect on its significance.",
        "Transitions guide the reader between ideas.",
      ],
      vocabulary: [
        ["Thesis", "The central argument of the essay."],
        ["Evidence", "Facts, quotes, or examples that support the argument."],
        ["Analysis", "Explaining how evidence proves the point."],
      ],
      facts: [
        "A thesis should be arguable — not just a statement of fact.",
      ],
      practice: [
        "Turn this topic into a thesis: 'social media and teens'.",
        "Draft three body-paragraph topic sentences for that thesis.",
      ],
    },
  },
  {
    keywords: ["world war", "wwii", "ww2", "hitler"],
    guide: {
      topic: "World War II",
      summary: "WWII (1939–1945) was a global conflict between the Allies and the Axis. It reshaped borders, economies, and international institutions.",
      keyConcepts: [
        "Causes included the harsh Treaty of Versailles, the Great Depression, and the rise of fascism.",
        "Major Allies: U.S., U.K., Soviet Union. Major Axis: Germany, Italy, Japan.",
        "Turning points included Stalingrad, D-Day, and Midway.",
        "The war ended in Europe (V-E Day, May 1945) and Asia (V-J Day, September 1945).",
      ],
      vocabulary: [
        ["Allies", "The coalition led by the U.S., U.K., and USSR."],
        ["Axis", "Germany, Italy, and Japan."],
        ["Blitzkrieg", "German 'lightning war' tactic."],
      ],
      facts: [
        "The U.N. was founded in 1945 in response to WWII.",
        "The Holocaust killed roughly six million Jews.",
      ],
      practice: [
        "List two long-term causes of WWII.",
        "Why was D-Day a turning point?",
        "How did WWII lead to the Cold War?",
      ],
    },
  },
  {
    keywords: ["industrial revolution", "factory", "steam"],
    guide: {
      topic: "The Industrial Revolution",
      summary: "The Industrial Revolution (late 1700s–1800s) shifted economies from farming and handcraft to factories and machines, starting in Britain.",
      keyConcepts: [
        "Steam power and mechanized textiles drove early growth.",
        "Urbanization surged as workers moved to cities.",
        "Working conditions were often harsh, sparking labor reforms.",
        "New transportation (railroads, steamships) reshaped trade.",
      ],
      vocabulary: [
        ["Urbanization", "The growth of cities as people move from rural areas."],
        ["Capitalism", "An economic system based on private ownership and markets."],
      ],
      facts: [
        "The spinning jenny and steam engine were key inventions.",
      ],
      practice: [
        "Why did the Industrial Revolution start in Britain?",
        "Name two social effects of industrialization.",
      ],
    },
  },
  {
    keywords: ["civil rights", "mlk", "martin luther king", "segregation"],
    guide: {
      topic: "The Civil Rights Movement",
      summary: "The Civil Rights Movement (1950s–60s) worked to end racial segregation and secure equal rights for Black Americans through nonviolent activism, legal action, and organizing.",
      keyConcepts: [
        "Brown v. Board (1954) ruled school segregation unconstitutional.",
        "The Montgomery Bus Boycott launched Dr. King to national leadership.",
        "The Civil Rights Act (1964) banned discrimination in public places and jobs.",
        "The Voting Rights Act (1965) protected access to the ballot.",
      ],
      vocabulary: [
        ["Segregation", "Enforced separation of racial groups."],
        ["Nonviolence", "A strategy of peaceful protest to create change."],
      ],
      facts: [
        "The March on Washington in 1963 drew about 250,000 people.",
      ],
      practice: [
        "Explain the significance of Brown v. Board of Education.",
        "How did nonviolent protest advance the movement's goals?",
      ],
    },
  },
];

const genericGuide = (topic: string): StudyGuide => ({
  topic,
  summary: `Here's a study guide on "${topic}". This is a demo — Clarity would normally build a full guide tailored to your notes and grade level, covering the core ideas, terms, and practice questions you need.`,
  keyConcepts: [
    `Start by defining the main idea of ${topic} in one sentence.`,
    `Identify 3–5 sub-topics that build on that idea.`,
    `Connect each sub-topic to a real-world example.`,
    `Notice where ${topic} overlaps with what you've already learned.`,
  ],
  vocabulary: [
    ["Main idea", "The central concept the topic revolves around."],
    ["Example", "A concrete case that illustrates the idea."],
    ["Application", "Where this idea shows up in the real world."],
  ],
  facts: [
    `${topic} is best learned by connecting it to something you already understand.`,
    "Active recall (self-quizzing) beats passive re-reading.",
  ],
  practice: [
    `Explain ${topic} in two sentences to a friend.`,
    `List three questions you still have about ${topic}.`,
    `Find one example of ${topic} in your daily life.`,
  ],
});

export function findStudyGuide(prompt: string): StudyGuide {
  const p = prompt.toLowerCase();
  for (const entry of studyGuideBank) {
    if (entry.keywords.some((k) => p.includes(k))) return entry.guide;
  }
  // Fall back to a subject-shaped generic guide using the prompt itself
  const trimmed = prompt.trim().replace(/[?.!]+$/, "");
  return genericGuide(trimmed.length > 0 ? trimmed : "Your topic");
}

// ============ TUTOR (rule-based Q&A) ============
const tutorAnswers: { keywords: string[]; answer: string }[] = [
  { keywords: ["quadratic formula"], answer: "The quadratic formula solves ax² + bx + c = 0. It's x = (−b ± √(b² − 4ac)) / (2a). The part under the root, b² − 4ac, is called the discriminant — it tells you how many real solutions there are." },
  { keywords: ["discriminant"], answer: "The discriminant is b² − 4ac. Positive means two real solutions, zero means one, and negative means the solutions are complex (no real roots)." },
  { keywords: ["slope"], answer: "Slope is how steep a line is — rise over run. In y = mx + b, m is the slope. A slope of 2 means y increases by 2 every time x increases by 1." },
  { keywords: ["pythagorean", "right triangle"], answer: "In any right triangle, a² + b² = c², where c is the hypotenuse (the side opposite the right angle). So if the legs are 3 and 4, the hypotenuse is 5." },
  { keywords: ["photosynthesis"], answer: "Photosynthesis is how plants turn sunlight, water, and CO₂ into glucose and oxygen. It happens in chloroplasts and has two stages: the light-dependent reactions and the Calvin cycle." },
  { keywords: ["mitochondri"], answer: "The mitochondrion is the organelle that makes ATP through cellular respiration — that's why it's called the 'powerhouse of the cell'." },
  { keywords: ["newton", "force", "f = ma"], answer: "Newton's Second Law says force equals mass times acceleration (F = ma). Push a heavier object with the same force and it accelerates less; push harder and it accelerates more." },
  { keywords: ["cell"], answer: "A cell is the basic unit of life. It has organelles like the nucleus (holds DNA), mitochondria (make energy), and ribosomes (build proteins), all inside a membrane." },
  { keywords: ["metaphor"], answer: "A metaphor is a direct comparison of two unlike things — like 'time is a thief.' Unlike a simile, it doesn't use 'like' or 'as'." },
  { keywords: ["simile"], answer: "A simile compares two things using 'like' or 'as' — 'brave as a lion,' or 'she runs like the wind.'" },
  { keywords: ["thesis"], answer: "A thesis is a single sentence that states the main argument of your essay. Make it specific and arguable — not just a fact." },
  { keywords: ["shakespeare"], answer: "William Shakespeare (1564–1616) was an English playwright and poet — he wrote Hamlet, Romeo and Juliet, Macbeth, and about 34 other plays plus 154 sonnets." },
  { keywords: ["wwii", "world war ii", "world war 2"], answer: "WWII (1939–1945) was fought between the Allies (U.S., U.K., Soviet Union) and the Axis (Germany, Italy, Japan). It ended in 1945 after Germany surrendered in May and Japan in September." },
  { keywords: ["industrial revolution"], answer: "The Industrial Revolution (late 1700s–1800s) shifted economies from farms and handcraft to factories and machines. It started in Britain, thanks to steam power, coal, and new textile technology." },
  { keywords: ["civil rights"], answer: "The Civil Rights Movement (1950s–60s) worked to end racial segregation in the U.S. through nonviolent protest and legal action. Key wins include Brown v. Board (1954), the Civil Rights Act (1964), and the Voting Rights Act (1965)." },
  { keywords: ["magna carta"], answer: "The Magna Carta was signed in 1215 in England. It limited the king's power and is considered a cornerstone of modern constitutional law." },
];

const subjectKeywords: Record<SubjectSlug, string[]> = {
  math: ["math", "algebra", "equation", "solve", "geometry", "triangle", "probability", "graph", "slope", "quadratic", "linear", "circle", "angle"],
  science: ["science", "biology", "physics", "chemistry", "cell", "atom", "molecule", "force", "newton", "photosynthesis", "ecosystem", "energy", "dna"],
  english: ["english", "essay", "thesis", "metaphor", "simile", "poem", "literature", "shakespeare", "grammar", "clause", "tone", "symbol"],
  history: ["history", "war", "revolution", "president", "wwii", "wwi", "civil rights", "magna carta", "cold war", "industrial"],
};

function detectSubject(prompt: string): SubjectSlug | null {
  const p = prompt.toLowerCase();
  let best: SubjectSlug | null = null;
  let bestScore = 0;
  (Object.keys(subjectKeywords) as SubjectSlug[]).forEach((s) => {
    const score = subjectKeywords[s].filter((k) => p.includes(k)).length;
    if (score > bestScore) {
      bestScore = score;
      best = s;
    }
  });
  return best;
}

export function tutorRespond(prompt: string): string {
  const p = prompt.toLowerCase().trim();
  if (!p) return "Ask me anything about math, science, English, or history!";
  if (/^(hi|hello|hey)\b/.test(p)) return "Hey! I'm your Clarity tutor. Ask me anything about math, science, English, or history and I'll walk you through it.";
  if (p.includes("thank")) return "You're welcome — happy to help. What else are you curious about?";

  for (const entry of tutorAnswers) {
    if (entry.keywords.some((k) => p.includes(k))) return entry.answer;
  }

  const subject = detectSubject(prompt);
  if (subject) {
    const topics = subjects.find((s) => s.slug === subject)?.topics ?? [];
    const suggestions = topics.slice(0, 3).map((t) => `"${t.title}"`).join(", ");
    return `That sounds like a ${subjectNames[subject]} question. I can go deep on topics like ${suggestions}. Try asking about one of those and I'll break it down step by step.`;
  }

  return "I focus on middle- and high-school math, science, English, and history. Try asking about something like the quadratic formula, photosynthesis, metaphors, or World War II — I can break any of those down for you.";
}
