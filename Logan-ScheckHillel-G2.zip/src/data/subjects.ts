export interface Subject {
  slug: string;
  name: string;
  tagline: string;
  color: string; // tailwind gradient stops
  topics: { title: string; description: string }[];
  reading: { title: string; summary: string }[];
}

export const subjects: Subject[] = [
  {
    slug: "math",
    name: "Math",
    tagline: "Algebra, geometry, and the language of patterns.",
    color: "from-sky-400 to-blue-600",
    topics: [
      { title: "Linear Equations", description: "Slope, intercepts, and graphing y = mx + b." },
      { title: "Quadratics", description: "Factoring, the quadratic formula, and parabolas." },
      { title: "Geometry Basics", description: "Angles, triangles, and the Pythagorean theorem." },
      { title: "Probability", description: "Independent events, combinations, and expected value." },
    ],
    reading: [
      { title: "How to read a graph", summary: "A short guide to axes, scales, and slope intuition." },
      { title: "Factoring cheat sheet", summary: "Common factoring patterns with worked examples." },
    ],
  },
  {
    slug: "science",
    name: "Science",
    tagline: "From cells to circuits — how the world works.",
    color: "from-cyan-400 to-sky-600",
    topics: [
      { title: "Cell Biology", description: "Organelles, membranes, and how cells make energy." },
      { title: "Newton's Laws", description: "Force, mass, and acceleration in everyday motion." },
      { title: "Chemical Bonds", description: "Ionic, covalent, and metallic bonding basics." },
      { title: "Ecosystems", description: "Producers, consumers, and energy flow." },
    ],
    reading: [
      { title: "The mitochondrion", summary: "Why it's called the powerhouse of the cell." },
      { title: "States of matter", summary: "Solids, liquids, gases, and phase changes." },
    ],
  },
  {
    slug: "english",
    name: "English",
    tagline: "Read closely. Write clearly. Think critically.",
    color: "from-indigo-400 to-blue-600",
    topics: [
      { title: "Literary Devices", description: "Metaphor, symbolism, foreshadowing, and tone." },
      { title: "Essay Structure", description: "Thesis, evidence, analysis, and conclusion." },
      { title: "Grammar Essentials", description: "Clauses, punctuation, and parallel structure." },
      { title: "Poetry Analysis", description: "Meter, rhyme, and reading between the lines." },
    ],
    reading: [
      { title: "Writing a strong thesis", summary: "Turn a topic into an argument in one sentence." },
      { title: "Close reading toolkit", summary: "Questions to ask when a passage feels dense." },
    ],
  },
  {
    slug: "history",
    name: "History",
    tagline: "Stories, causes, and consequences across time.",
    color: "from-blue-400 to-indigo-600",
    topics: [
      { title: "American Revolution", description: "Causes, key figures, and lasting outcomes." },
      { title: "Industrial Revolution", description: "Steam, factories, and social change." },
      { title: "World War II", description: "Global conflict, alliances, and aftermath." },
      { title: "Civil Rights Era", description: "Movements, laws, and enduring impact." },
    ],
    reading: [
      { title: "Primary vs. secondary sources", summary: "How to weigh evidence in a history essay." },
      { title: "Timeline reading tips", summary: "Spotting cause-and-effect over decades." },
    ],
  },
];
