import { useEffect, useState } from "react";

const STORAGE_KEY = "clarity.studyTime.v1";
// Structure: { [YYYY-MM-DD]: seconds }

function today(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function loadAll(): Record<string, number> {
  if (typeof window === "undefined") return {};
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

function saveAll(data: Record<string, number>) {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch {
    // ignore
  }
}

// Increment ~every second while the tab is visible & focused.
export function useStudyTimeTracker() {
  useEffect(() => {
    let last = Date.now();
    const tick = () => {
      const now = Date.now();
      const dt = Math.min(5, Math.max(0, (now - last) / 1000)); // clamp to 5s
      last = now;
      if (document.visibilityState !== "visible") return;
      const data = loadAll();
      const key = today();
      data[key] = Math.round((data[key] ?? 0) + dt);
      saveAll(data);
    };
    const id = window.setInterval(tick, 1000);
    const onVis = () => {
      last = Date.now();
    };
    document.addEventListener("visibilitychange", onVis);
    return () => {
      window.clearInterval(id);
      document.removeEventListener("visibilitychange", onVis);
    };
  }, []);
}

// Returns last 7 days of study time in minutes (oldest -> newest, includes today).
export function useWeeklyStudyTime() {
  const [days, setDays] = useState<{ day: string; date: string; minutes: number; seconds: number }[]>([]);

  useEffect(() => {
    const compute = () => {
      const data = loadAll();
      const out: { day: string; date: string; minutes: number; seconds: number }[] = [];
      const now = new Date();
      const labels = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
      for (let i = 6; i >= 0; i--) {
        const d = new Date(now);
        d.setDate(now.getDate() - i);
        const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
        const seconds = data[key] ?? 0;
        out.push({ day: labels[d.getDay()], date: key, seconds, minutes: Math.round(seconds / 60) });
      }
      setDays(out);
    };
    compute();
    const id = window.setInterval(compute, 5000);
    return () => window.clearInterval(id);
  }, []);

  return days;
}

export function formatDuration(seconds: number): string {
  if (seconds < 60) return `${seconds}s`;
  const m = Math.floor(seconds / 60);
  if (m < 60) return `${m}m`;
  const h = Math.floor(m / 60);
  const rem = m % 60;
  return rem === 0 ? `${h}h` : `${h}h ${rem}m`;
}

export function resetStudyTime() {
  try {
    window.localStorage.removeItem(STORAGE_KEY);
  } catch {
    // ignore
  }
}
