import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

export type PlannerType = "assignment" | "quiz" | "test" | "study_session";
export type PlannerPriority = "low" | "medium" | "high";
export type PlannerStatus = "pending" | "completed" | "taken";
export type PlannerReminder = "none" | "1w" | "3d" | "1d" | "3h" | "1h" | "at_due";
export type PlannerRepeat = "none" | "daily" | "weekly" | "monthly";

export interface PlannerEvent {
  id: string;
  user_id: string;
  type: PlannerType;
  title: string;
  subject: string | null;
  description: string | null;
  due_date: string; // YYYY-MM-DD
  due_time: string | null; // HH:MM:SS
  priority: PlannerPriority;
  estimated_minutes: number | null;
  reminder: PlannerReminder;
  repeat: PlannerRepeat;
  duration_minutes: number | null;
  goal: string | null;
  linked_event_id: string | null;
  status: PlannerStatus;
  completed_at: string | null;
  reminded_at: string | null;
  created_at: string;
  updated_at: string;
}

export type PlannerInput = Omit<
  PlannerEvent,
  "id" | "user_id" | "created_at" | "updated_at" | "completed_at" | "reminded_at" | "status"
> & { status?: PlannerStatus };

export function usePlannerEvents() {
  const { user } = useAuth();
  const [events, setEvents] = useState<PlannerEvent[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase
      .from("planner_events")
      .select("*")
      .order("due_date", { ascending: true })
      .order("due_time", { ascending: true, nullsFirst: true });
    setEvents((data as PlannerEvent[]) ?? []);
    setLoading(false);
  }, [user]);

  useEffect(() => {
    if (!user) return;
    load();
    const channel = supabase
      .channel("planner_events_" + user.id)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "planner_events", filter: `user_id=eq.${user.id}` },
        () => load(),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, load]);

  const create = useCallback(
    async (input: PlannerInput) => {
      if (!user) throw new Error("Not signed in");
      const { data, error } = await supabase
        .from("planner_events")
        .insert({ ...input, user_id: user.id })
        .select()
        .single();
      if (error) throw error;
      await load();
      return data as PlannerEvent;
    },
    [user, load],
  );

  const update = useCallback(
    async (id: string, patch: Partial<PlannerInput> & { status?: PlannerStatus; completed_at?: string | null }) => {
      const { error } = await supabase.from("planner_events").update(patch).eq("id", id);
      if (error) throw error;
      await load();
    },
    [load],
  );

  const remove = useCallback(
    async (id: string) => {
      const { error } = await supabase.from("planner_events").delete().eq("id", id);
      if (error) throw error;
      await load();
    },
    [load],
  );

  const duplicate = useCallback(
    async (ev: PlannerEvent) => {
      if (!user) return;
      const {
        id: _id,
        user_id: _uid,
        created_at: _c,
        updated_at: _u,
        completed_at: _co,
        reminded_at: _r,
        ...rest
      } = ev;
      await supabase
        .from("planner_events")
        .insert({ ...rest, user_id: user.id, status: "pending", title: `${ev.title} (copy)` });
      await load();
    },
    [user, load],
  );

  const toggleComplete = useCallback(
    async (ev: PlannerEvent) => {
      const doneStatus: PlannerStatus =
        ev.type === "quiz" || ev.type === "test" ? "taken" : "completed";
      const isDone = ev.status !== "pending";
      await update(ev.id, {
        status: isDone ? "pending" : doneStatus,
        completed_at: isDone ? null : new Date().toISOString(),
      });
    },
    [update],
  );

  const move = useCallback(
    async (id: string, newDate: string) => {
      await update(id, { due_date: newDate });
    },
    [update],
  );

  const clearAll = useCallback(async () => {
    if (!user) return;
    const { error } = await supabase.from("planner_events").delete().eq("user_id", user.id);
    if (error) throw error;
    await load();
  }, [user, load]);

  return { events, loading, create, update, remove, duplicate, toggleComplete, move, clearAll, reload: load };
}
