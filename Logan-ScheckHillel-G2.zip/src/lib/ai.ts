import { supabase } from "@/integrations/supabase/client";

type ChatMsg = { role: "user" | "assistant"; content: string };

async function getContext() {
  const { data } = await supabase.auth.getUser();
  const uid = data.user?.id;
  if (!uid) return {};
  const { data: profile } = await supabase
    .from("profiles")
    .select("display_name, grade, interests")
    .eq("id", uid)
    .maybeSingle();
  const today = new Date().toISOString().slice(0, 10);
  const end = new Date();
  end.setDate(end.getDate() + 21);
  const endStr = end.toISOString().slice(0, 10);
  const { data: planner } = await supabase
    .from("planner_events")
    .select("type, title, subject, due_date, due_time, priority, status")
    .gte("due_date", today)
    .lte("due_date", endStr)
    .eq("status", "pending")
    .order("due_date", { ascending: true })
    .limit(30);
  return {
    name: profile?.display_name ?? undefined,
    grade: profile?.grade ?? undefined,
    interests: profile?.interests ?? [],
    planner: planner ?? [],
  };
}

async function invoke(payload: Record<string, unknown>) {
  const ctx = await getContext();
  const { data, error } = await supabase.functions.invoke("ai-chat", {
    body: { ...payload, context: ctx },
  });
  if (error) {
    // Try to read the friendly error the edge function returned in its body.
    let friendly: string | null = null;
    const ctxErr = error as unknown as { context?: Response };
    const res = ctxErr.context;
    if (res && typeof res.json === "function") {
      try {
        const body = await res.clone().json();
        if (body && typeof body.error === "string") friendly = body.error;
      } catch {
        // ignore
      }
    }
    throw new Error(friendly || "We couldn't reach the AI. Please try again in a moment.");
  }
  if (data?.error) throw new Error(data.error);
  return data;
}

export async function aiChat(
  mode: "chat" | "study-guide",
  messages: ChatMsg[],
  subject?: string,
): Promise<string> {
  const data = await invoke({ mode, messages, subject });
  return data.text as string;
}

export async function aiFlashcards(subject: string, count = 8) {
  const data = await invoke({ mode: "flashcards", subject, count });
  return data.cards as { front: string; back: string }[];
}

export type QuizDifficulty = "easy" | "medium" | "hard";

export async function aiQuiz(subject: string, count = 5, difficulty: QuizDifficulty = "medium") {
  const data = await invoke({ mode: "quiz", subject, count, difficulty });
  return data.questions as {
    q: string;
    options: string[];
    answer: number;
    explain: string;
  }[];
}
