import { BookOpen, ClipboardList, GraduationCap, Target, type LucideIcon } from "lucide-react";
import type { PlannerEvent, PlannerType, PlannerPriority } from "@/hooks/usePlannerEvents";

export const TYPE_META: Record<
  PlannerType,
  { label: string; icon: LucideIcon; emoji: string; accent: string; dot: string; ring: string }
> = {
  assignment: {
    label: "Assignment",
    icon: BookOpen,
    emoji: "📚",
    accent: "bg-primary/10 text-primary border-primary/30",
    dot: "bg-primary",
    ring: "ring-primary/40",
  },
  quiz: {
    label: "Quiz",
    icon: ClipboardList,
    emoji: "📝",
    accent: "bg-accent text-accent-foreground border-primary/20",
    dot: "bg-primary-glow",
    ring: "ring-primary-glow/50",
  },
  test: {
    label: "Test / Exam",
    icon: GraduationCap,
    emoji: "📖",
    accent: "bg-destructive/10 text-destructive border-destructive/30",
    dot: "bg-destructive",
    ring: "ring-destructive/40",
  },
  study_session: {
    label: "Study Session",
    icon: Target,
    emoji: "🎯",
    accent: "bg-success/10 text-success border-success/30",
    dot: "bg-success",
    ring: "ring-success/40",
  },
};

export const SUBJECTS = ["Math", "Science", "English", "History"] as const;

export const PRIORITY_META: Record<PlannerPriority, { label: string; className: string; rank: number }> = {
  high: { label: "High", className: "bg-destructive/15 text-destructive border-destructive/30", rank: 0 },
  medium: { label: "Medium", className: "bg-primary/15 text-primary border-primary/30", rank: 1 },
  low: { label: "Low", className: "bg-muted text-muted-foreground border-border", rank: 2 },
};

export function ymd(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function fromYmd(s: string): Date {
  const [y, m, d] = s.split("-").map(Number);
  return new Date(y, (m ?? 1) - 1, d ?? 1);
}

export function todayYmd(): string {
  return ymd(new Date());
}

export function isOverdue(ev: PlannerEvent): boolean {
  if (ev.status !== "pending") return false;
  return ev.due_date < todayYmd();
}

export function formatTime(t: string | null): string {
  if (!t) return "";
  const [h, m] = t.split(":").map(Number);
  const d = new Date();
  d.setHours(h, m, 0, 0);
  return d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
}

export function formatDateLabel(dateStr: string): string {
  const d = fromYmd(dateStr);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const diff = Math.round((d.getTime() - today.getTime()) / 86400000);
  if (diff === 0) return "Today";
  if (diff === 1) return "Tomorrow";
  if (diff === -1) return "Yesterday";
  return d.toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" });
}

export function comparator(sort: "due" | "priority") {
  return (a: PlannerEvent, b: PlannerEvent) => {
    if (sort === "priority") {
      const p = PRIORITY_META[a.priority].rank - PRIORITY_META[b.priority].rank;
      if (p !== 0) return p;
    }
    if (a.due_date !== b.due_date) return a.due_date < b.due_date ? -1 : 1;
    const at = a.due_time ?? "99:99";
    const bt = b.due_time ?? "99:99";
    return at.localeCompare(bt);
  };
}

export function workloadLevel(count: number): { label: string; className: string } {
  if (count >= 8) return { label: "Heavy", className: "bg-destructive/15 text-destructive border-destructive/30" };
  if (count >= 4) return { label: "Moderate", className: "bg-primary/15 text-primary border-primary/30" };
  return { label: "Light", className: "bg-success/15 text-success border-success/30" };
}
