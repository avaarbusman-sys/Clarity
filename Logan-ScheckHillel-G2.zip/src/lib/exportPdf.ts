import jsPDF from "jspdf";
import html2canvas from "html2canvas";

export async function exportElementToPdf(el: HTMLElement, filename: string) {
  const canvas = await html2canvas(el, {
    scale: 2,
    backgroundColor: "#ffffff",
    useCORS: true,
  });
  const imgData = canvas.toDataURL("image/png");
  const pdf = new jsPDF({ unit: "pt", format: "a4" });
  const pageW = pdf.internal.pageSize.getWidth();
  const pageH = pdf.internal.pageSize.getHeight();
  const margin = 32;
  const imgW = pageW - margin * 2;
  const imgH = (canvas.height * imgW) / canvas.width;

  let heightLeft = imgH;
  let position = margin;
  pdf.addImage(imgData, "PNG", margin, position, imgW, imgH);
  heightLeft -= pageH - margin * 2;
  while (heightLeft > 0) {
    pdf.addPage();
    position = margin - (imgH - heightLeft);
    pdf.addImage(imgData, "PNG", margin, position, imgW, imgH);
    heightLeft -= pageH - margin * 2;
  }
  pdf.save(filename);
}

export async function exportStudyGuideToPdf(
  messages: { role: "user" | "assistant"; content: string }[],
  renderMarkdown: (content: string) => Promise<string> | string,
  filename = "study-guide.pdf",
) {
  const container = document.createElement("div");
  container.style.position = "fixed";
  container.style.left = "-10000px";
  container.style.top = "0";
  container.style.width = "800px";
  container.style.padding = "32px";
  container.style.background = "#ffffff";
  container.style.color = "#0b1220";
  container.style.fontFamily =
    "system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif";
  container.style.fontSize = "14px";
  container.style.lineHeight = "1.6";

  const title = document.createElement("h1");
  title.textContent = "Clarity — Study Guide";
  title.style.fontSize = "22px";
  title.style.marginBottom = "4px";
  title.style.color = "#1d4ed8";
  container.appendChild(title);

  const date = document.createElement("div");
  date.textContent = new Date().toLocaleString();
  date.style.fontSize = "12px";
  date.style.color = "#64748b";
  date.style.marginBottom = "20px";
  container.appendChild(date);

  for (const m of messages) {
    const block = document.createElement("div");
    block.style.marginBottom = "16px";
    block.style.padding = "12px 14px";
    block.style.borderRadius = "10px";
    block.style.border = "1px solid #e2e8f0";
    block.style.background = m.role === "user" ? "#eff6ff" : "#f8fafc";

    const label = document.createElement("div");
    label.textContent = m.role === "user" ? "You" : "Clarity";
    label.style.fontSize = "11px";
    label.style.fontWeight = "600";
    label.style.textTransform = "uppercase";
    label.style.letterSpacing = "0.08em";
    label.style.color = m.role === "user" ? "#1d4ed8" : "#334155";
    label.style.marginBottom = "6px";
    block.appendChild(label);

    const body = document.createElement("div");
    const html = await renderMarkdown(m.content);
    body.innerHTML = html;
    block.appendChild(body);
    container.appendChild(block);
  }

  document.body.appendChild(container);
  try {
    await exportElementToPdf(container, filename);
  } finally {
    document.body.removeChild(container);
  }
}
