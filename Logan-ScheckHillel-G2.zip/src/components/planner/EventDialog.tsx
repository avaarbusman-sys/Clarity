import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { TYPE_META, SUBJECTS } from "@/lib/planner";
import type {
  PlannerEvent,
  PlannerInput,
  PlannerPriority,
  PlannerReminder,
  PlannerRepeat,
  PlannerType,
} from "@/hooks/usePlannerEvents";
import { toast } from "@/hooks/use-toast";

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  initial?: Partial<PlannerEvent> | null;
  defaultDate?: string;
  onSave: (input: PlannerInput, id?: string) => Promise<void>;
  events?: PlannerEvent[];
}

const TYPES: PlannerType[] = ["assignment", "quiz", "test", "study_session"];

export function EventDialog({ open, onOpenChange, initial, defaultDate, onSave, events = [] }: Props) {
  const editing = Boolean(initial?.id);
  const [step, setStep] = useState<"type" | "form">(editing ? "form" : "type");
  const [type, setType] = useState<PlannerType>((initial?.type as PlannerType) ?? "assignment");
  const [title, setTitle] = useState(initial?.title ?? "");
  const [subject, setSubject] = useState<string>(initial?.subject ?? "Math");
  const [dueDate, setDueDate] = useState(initial?.due_date ?? defaultDate ?? new Date().toISOString().slice(0, 10));
  const [dueTime, setDueTime] = useState(initial?.due_time?.slice(0, 5) ?? "");
  const [priority, setPriority] = useState<PlannerPriority>((initial?.priority as PlannerPriority) ?? "medium");
  const [description, setDescription] = useState(initial?.description ?? "");
  const [estimated, setEstimated] = useState<string>(initial?.estimated_minutes?.toString() ?? "");
  const [reminder, setReminder] = useState<PlannerReminder>((initial?.reminder as PlannerReminder) ?? "1d");
  const [repeatValue, setRepeatValue] = useState<PlannerRepeat>((initial?.repeat as PlannerRepeat) ?? "none");
  const [duration, setDuration] = useState<string>(initial?.duration_minutes?.toString() ?? "");
  const [goal, setGoal] = useState(initial?.goal ?? "");
  const [linkedId, setLinkedId] = useState<string>(initial?.linked_event_id ?? "none");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!open) return;
    setStep(editing ? "form" : "type");
    setType((initial?.type as PlannerType) ?? "assignment");
    setTitle(initial?.title ?? "");
    setSubject(initial?.subject ?? "Math");
    setDueDate(initial?.due_date ?? defaultDate ?? new Date().toISOString().slice(0, 10));
    setDueTime(initial?.due_time?.slice(0, 5) ?? "");
    setPriority((initial?.priority as PlannerPriority) ?? "medium");
    setDescription(initial?.description ?? "");
    setEstimated(initial?.estimated_minutes?.toString() ?? "");
    setReminder((initial?.reminder as PlannerReminder) ?? "1d");
    setRepeatValue((initial?.repeat as PlannerRepeat) ?? "none");
    setDuration(initial?.duration_minutes?.toString() ?? "");
    setGoal(initial?.goal ?? "");
    setLinkedId(initial?.linked_event_id ?? "none");
  }, [open, initial, defaultDate, editing]);

  const linkable = events.filter((e) => e.type !== "study_session" && e.id !== initial?.id);

  const todayStr = new Date().toISOString().slice(0, 10);

  async function submit() {
    if (!title.trim()) {
      toast({ title: "Add a title", description: "Please give your event a name.", variant: "destructive" });
      return;
    }
    if (dueDate < todayStr) {
      toast({ title: "Invalid date", description: "You can't schedule events in the past.", variant: "destructive" });
      return;
    }
    if (dueDate === todayStr && dueTime) {
      const now = new Date();
      const hhmm = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
      if (dueTime < hhmm) {
        toast({ title: "Invalid time", description: "Pick a time later than now.", variant: "destructive" });
        return;
      }
    }
    setSaving(true);
    try {
      const input: PlannerInput = {
        type,
        title: title.trim(),
        subject: subject || null,
        description: description.trim() || null,
        due_date: dueDate,
        due_time: dueTime ? `${dueTime}:00` : null,
        priority,
        estimated_minutes: estimated ? Number(estimated) : null,
        reminder,
        repeat: repeatValue,
        duration_minutes: type === "study_session" && duration ? Number(duration) : null,
        goal: type === "study_session" ? goal.trim() || null : null,
        linked_event_id: type === "study_session" && linkedId !== "none" ? linkedId : null,
      };
      await onSave(input, initial?.id);
      onOpenChange(false);
    } catch (err) {
      toast({
        title: "Couldn't save event",
        description: err instanceof Error ? err.message : "Please try again.",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg glass-strong">
        <DialogHeader>
          <DialogTitle>{editing ? "Edit event" : step === "type" ? "New event" : `New ${TYPE_META[type].label.toLowerCase()}`}</DialogTitle>
        </DialogHeader>

        {step === "type" ? (
          <div className="grid grid-cols-2 gap-3 py-2">
            {TYPES.map((t) => {
              const meta = TYPE_META[t];
              const Icon = meta.icon;
              return (
                <button
                  key={t}
                  onClick={() => {
                    setType(t);
                    setStep("form");
                  }}
                  className={cn(
                    "rounded-2xl border p-4 text-left transition-all hover:-translate-y-0.5 hover:shadow-[var(--shadow-soft)]",
                    "bg-card/60 backdrop-blur border-border",
                  )}
                >
                  <div className={cn("h-10 w-10 rounded-xl flex items-center justify-center mb-3 border", meta.accent)}>
                    <Icon className="h-5 w-5" />
                  </div>
                  <div className="font-semibold">{meta.emoji} {meta.label}</div>
                </button>
              );
            })}
          </div>
        ) : (
          <div className="space-y-4 py-1 max-h-[65vh] overflow-y-auto pr-1">
            <div>
              <Label>Title</Label>
              <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Algebra chapter 4" autoFocus />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Subject</Label>
                <Select value={subject} onValueChange={setSubject}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {SUBJECTS.map((s) => (
                      <SelectItem key={s} value={s}>{s}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Priority</Label>
                <Select value={priority} onValueChange={(v) => setPriority(v as PlannerPriority)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Due date</Label>
                <Input type="date" min={todayStr} value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
              </div>
              <div>
                <Label>Due time (optional)</Label>
                <Input type="time" value={dueTime} onChange={(e) => setDueTime(e.target.value)} />
              </div>
            </div>

            <div>
              <Label>Description / notes</Label>
              <Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={3} placeholder="Anything you want to remember" />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Estimated study time (min)</Label>
                <Input type="number" min={0} value={estimated} onChange={(e) => setEstimated(e.target.value)} placeholder="30" />
              </div>
              <div>
                <Label>Reminder</Label>
                <Select value={reminder} onValueChange={(v) => setReminder(v as PlannerReminder)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Off</SelectItem>
                    <SelectItem value="1w">1 week before</SelectItem>
                    <SelectItem value="3d">3 days before</SelectItem>
                    <SelectItem value="1d">1 day before</SelectItem>
                    <SelectItem value="3h">3 hours before</SelectItem>
                    <SelectItem value="1h">1 hour before</SelectItem>
                    <SelectItem value="at_due">At due time</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label>Repeat</Label>
              <Select value={repeatValue} onValueChange={(v) => setRepeatValue(v as PlannerRepeat)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Does not repeat</SelectItem>
                  <SelectItem value="daily">Daily</SelectItem>
                  <SelectItem value="weekly">Weekly</SelectItem>
                  <SelectItem value="monthly">Monthly</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {type === "study_session" && (
              <div className="space-y-4 rounded-2xl p-4 bg-accent/40 border border-primary/10">
                <div className="text-xs uppercase tracking-[0.14em] text-primary font-medium">Study session</div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label>Planned duration (min)</Label>
                    <Input type="number" min={0} value={duration} onChange={(e) => setDuration(e.target.value)} placeholder="45" />
                  </div>
                  <div>
                    <Label>Linked event</Label>
                    <Select value={linkedId} onValueChange={setLinkedId}>
                      <SelectTrigger><SelectValue placeholder="None" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">None</SelectItem>
                        {linkable.map((e) => (
                          <SelectItem key={e.id} value={e.id}>{TYPE_META[e.type].emoji} {e.title}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div>
                  <Label>Study goal</Label>
                  <Input value={goal} onChange={(e) => setGoal(e.target.value)} placeholder="Review chapters 3 & 4" />
                </div>
              </div>
            )}
          </div>
        )}

        <DialogFooter>
          {step === "form" && (
            <>
              {!editing && (
                <Button variant="ghost" onClick={() => setStep("type")}>Back</Button>
              )}
              <Button onClick={submit} disabled={saving} className="gradient-bg text-primary-foreground">
                {saving ? "Saving..." : editing ? "Save changes" : "Create event"}
              </Button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
