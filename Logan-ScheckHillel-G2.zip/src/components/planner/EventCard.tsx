import { MoreHorizontal, Check, Copy, Pencil, Trash2, Clock, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";
import { TYPE_META, PRIORITY_META, formatTime, isOverdue, formatDateLabel } from "@/lib/planner";
import type { PlannerEvent } from "@/hooks/usePlannerEvents";

interface Props {
  event: PlannerEvent;
  onEdit: (e: PlannerEvent) => void;
  onDelete: (e: PlannerEvent) => void;
  onDuplicate: (e: PlannerEvent) => void;
  onToggle: (e: PlannerEvent) => void;
  showDate?: boolean;
  draggable?: boolean;
}

export function EventCard({ event, onEdit, onDelete, onDuplicate, onToggle, showDate, draggable }: Props) {
  const meta = TYPE_META[event.type];
  const Icon = meta.icon;
  const done = event.status !== "pending";
  const overdue = isOverdue(event);

  return (
    <div
      draggable={draggable}
      onDragStart={(e) => {
        if (!draggable) return;
        e.dataTransfer.setData("text/plain", event.id);
        e.dataTransfer.effectAllowed = "move";
      }}
      className={cn(
        "group relative rounded-2xl border bg-card/70 backdrop-blur p-3 transition-all",
        "hover:shadow-[var(--shadow-soft)] hover:-translate-y-0.5",
        done && "opacity-60",
        overdue && "border-destructive/40",
      )}
    >
      <div className="flex items-start gap-3">
        <button
          onClick={() => onToggle(event)}
          className={cn(
            "mt-0.5 h-5 w-5 shrink-0 rounded-md border flex items-center justify-center transition-colors",
            done ? "bg-primary border-primary text-primary-foreground" : "border-border hover:border-primary",
          )}
          aria-label={done ? "Mark as pending" : "Mark as done"}
        >
          {done && <Check className="h-3.5 w-3.5" />}
        </button>

        <div className={cn("h-9 w-9 rounded-xl flex items-center justify-center border shrink-0", meta.accent)}>
          <Icon className="h-4 w-4" />
        </div>

        <div className="min-w-0 flex-1">
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0">
              <div className={cn("font-semibold text-sm truncate", done && "line-through")}>{event.title}</div>
              <div className="mt-0.5 flex items-center flex-wrap gap-x-2 gap-y-1 text-xs text-muted-foreground">
                {event.subject && <span>{event.subject}</span>}
                {showDate && (
                  <span className={cn(overdue && "text-destructive font-medium")}>
                    {formatDateLabel(event.due_date)}
                  </span>
                )}
                {event.due_time && (
                  <span className="inline-flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {formatTime(event.due_time)}
                  </span>
                )}
                {overdue && (
                  <span className="inline-flex items-center gap-1 text-destructive">
                    <AlertTriangle className="h-3 w-3" /> Overdue
                  </span>
                )}
              </div>
            </div>

            <div className="flex items-center gap-1 shrink-0">
              <span
                className={cn(
                  "hidden sm:inline-flex text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-full border font-medium",
                  PRIORITY_META[event.priority].className,
                )}
              >
                {PRIORITY_META[event.priority].label}
              </span>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-7 w-7">
                    <MoreHorizontal className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={() => onEdit(event)}><Pencil className="h-4 w-4 mr-2" />Edit</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => onDuplicate(event)}><Copy className="h-4 w-4 mr-2" />Duplicate</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => onDelete(event)} className="text-destructive">
                    <Trash2 className="h-4 w-4 mr-2" />Delete
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
          {event.description && (
            <div className="mt-1.5 text-xs text-muted-foreground line-clamp-2">{event.description}</div>
          )}
        </div>
      </div>
    </div>
  );
}
