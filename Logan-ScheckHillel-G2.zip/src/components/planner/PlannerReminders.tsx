import { useEffect, useRef } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import type { PlannerEvent, PlannerReminder } from "@/hooks/usePlannerEvents";
import { TYPE_META } from "@/lib/planner";

const OFFSETS: Record<PlannerReminder, number | null> = {
  none: null,
  "1w": 7 * 24 * 60,
  "3d": 3 * 24 * 60,
  "1d": 24 * 60,
  "3h": 3 * 60,
  "1h": 60,
  at_due: 0,
};

function dueDateTime(ev: PlannerEvent): Date {
  const [y, m, d] = ev.due_date.split("-").map(Number);
  const t = ev.due_time ?? "23:59:00";
  const [hh, mm] = t.split(":").map(Number);
  return new Date(y, m - 1, d, hh ?? 23, mm ?? 59, 0, 0);
}

/**
 * Background poller that fires an in-app toast when an event's reminder
 * threshold has been crossed. Persists "already reminded" state on the row
 * via `reminded_at` so the same reminder doesn't fire twice.
 */
export function PlannerReminders() {
  const { user } = useAuth();
  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    if (!user) return;

    async function check() {
      const { data } = await supabase
        .from("planner_events")
        .select("*")
        .eq("status", "pending")
        .neq("reminder", "none")
        .is("reminded_at", null);
      const events = (data as PlannerEvent[] | null) ?? [];
      const now = Date.now();
      for (const ev of events) {
        const offset = OFFSETS[ev.reminder];
        if (offset === null) continue;
        const target = dueDateTime(ev).getTime() - offset * 60 * 1000;
        if (now >= target && now - target < 24 * 60 * 60 * 1000) {
          const meta = TYPE_META[ev.type];
          toast(`${meta.emoji} ${ev.title}`, {
            description: `${meta.label} is coming up — ${new Date(dueDateTime(ev)).toLocaleString()}`,
          });
          await supabase
            .from("planner_events")
            .update({ reminded_at: new Date().toISOString() })
            .eq("id", ev.id);
        }
      }
    }

    check();
    timerRef.current = window.setInterval(check, 60 * 1000);
    return () => {
      if (timerRef.current) window.clearInterval(timerRef.current);
    };
  }, [user]);

  return null;
}
