import { Link } from "react-router-dom";
import { ArrowRight, CalendarDays } from "lucide-react";
import { useMemo } from "react";
import { usePlannerEvents, type PlannerEvent, type PlannerType } from "@/hooks/usePlannerEvents";
import { TYPE_META, todayYmd, formatDateLabel, formatTime, isOverdue } from "@/lib/planner";
import { cn } from "@/lib/utils";

function nextByType(events: PlannerEvent[], type: PlannerType): PlannerEvent | undefined {
  return events.find((e) => e.type === type && e.status === "pending" && e.due_date >= todayYmd());
}

export function UpcomingPlannerCard() {
  const { events } = usePlannerEvents();

  const { today, thisWeek, nexts } = useMemo(() => {
    const t = todayYmd();
    const end = new Date();
    end.setDate(end.getDate() + 7);
    const endStr = end.toISOString().slice(0, 10);
    const upcoming = events.filter((e) => e.status === "pending" && !isOverdue(e));
    return {
      today: upcoming.filter((e) => e.due_date === t),
      thisWeek: upcoming.filter((e) => e.due_date >= t && e.due_date <= endStr),
      nexts: {
        assignment: nextByType(upcoming, "assignment"),
        quiz: nextByType(upcoming, "quiz"),
        test: nextByType(upcoming, "test"),
        study_session: nextByType(upcoming, "study_session"),
      },
    };
  }, [events]);

  const nextRows: { key: string; label: string; ev?: PlannerEvent }[] = [
    { key: "assignment", label: "Next assignment", ev: nexts.assignment },
    { key: "quiz", label: "Next quiz", ev: nexts.quiz },
    { key: "test", label: "Next test", ev: nexts.test },
    { key: "study_session", label: "Next study session", ev: nexts.study_session },
  ];

  return (
    <div className="glass rounded-3xl p-6 md:p-8">
      <div className="flex items-center justify-between mb-4">
        <div>
          <div className="text-xs uppercase tracking-[0.14em] text-primary font-medium">Planner</div>
          <h3 className="text-xl font-semibold tracking-tight mt-1">Upcoming</h3>
        </div>
        <Link to="/planner" className="text-sm text-primary font-medium inline-flex items-center gap-1 hover:gap-2 transition-all">
          Open planner <ArrowRight className="h-3.5 w-3.5" />
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
        <SummaryTile label="Due today" count={today.length} />
        <SummaryTile label="This week" count={thisWeek.length} />
      </div>

      <div className="space-y-2">
        {nextRows.map((row) => (
          <NextRow key={row.key} label={row.label} event={row.ev} />
        ))}
      </div>

      {events.length === 0 && (
        <div className="mt-4 rounded-2xl border border-dashed border-border/70 p-6 text-center">
          <CalendarDays className="h-5 w-5 mx-auto text-muted-foreground mb-2" />
          <p className="text-sm text-muted-foreground">
            Nothing planned yet.{" "}
            <Link to="/planner" className="text-primary font-medium">Add your first event</Link>.
          </p>
        </div>
      )}
    </div>
  );
}

function SummaryTile({ label, count }: { label: string; count: number }) {
  return (
    <div className="rounded-2xl border border-border bg-card/50 p-4">
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className="text-2xl font-semibold mt-1">{count}</div>
    </div>
  );
}

function NextRow({ label, event }: { label: string; event?: PlannerEvent }) {
  if (!event) {
    return (
      <div className="flex items-center justify-between rounded-xl px-3 py-2 text-sm text-muted-foreground">
        <span>{label}</span>
        <span className="text-xs">None</span>
      </div>
    );
  }
  const meta = TYPE_META[event.type];
  const Icon = meta.icon;
  return (
    <Link
      to={`/planner?event=${event.id}`}
      className="flex items-center gap-3 rounded-xl px-3 py-2 hover:bg-accent/50 transition-colors"
    >
      <div className={cn("h-8 w-8 rounded-lg border flex items-center justify-center", meta.accent)}>
        <Icon className="h-4 w-4" />
      </div>
      <div className="min-w-0 flex-1">
        <div className="text-xs text-muted-foreground">{label}</div>
        <div className="text-sm font-medium truncate">{event.title}</div>
      </div>
      <div className="text-xs text-muted-foreground text-right shrink-0">
        <div>{formatDateLabel(event.due_date)}</div>
        {event.due_time && <div>{formatTime(event.due_time)}</div>}
      </div>
    </Link>
  );
}
