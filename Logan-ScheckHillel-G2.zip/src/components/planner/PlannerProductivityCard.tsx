import { useMemo } from "react";
import { CheckCircle2, ClipboardList, GraduationCap, Target, TrendingUp } from "lucide-react";
import { usePlannerEvents, type PlannerEvent } from "@/hooks/usePlannerEvents";
import { isOverdue, todayYmd, workloadLevel } from "@/lib/planner";
import { cn } from "@/lib/utils";

function within(ev: PlannerEvent, days: number) {
  if (!ev.completed_at) return false;
  const t = new Date(ev.completed_at).getTime();
  return Date.now() - t <= days * 24 * 60 * 60 * 1000;
}

export function PlannerProductivityCard() {
  const { events } = usePlannerEvents();

  const stats = useMemo(() => {
    const done = events.filter((e) => e.status !== "pending");
    const assignments = done.filter((e) => e.type === "assignment").length;
    const quizzes = done.filter((e) => e.type === "quiz").length;
    const tests = done.filter((e) => e.type === "test").length;
    const sessions = done.filter((e) => e.type === "study_session").length;

    const week = events.filter((e) => within(e, 7)).length;
    const month = events.filter((e) => within(e, 30)).length;

    const total = events.length;
    const completionRate = total > 0 ? Math.round((done.length / total) * 100) : 0;

    const today = todayYmd();
    const end = new Date();
    end.setDate(end.getDate() + 7);
    const endStr = end.toISOString().slice(0, 10);
    const upcoming = events.filter((e) => e.status === "pending" && e.due_date >= today && e.due_date <= endStr).length;
    const overdue = events.filter(isOverdue).length;

    return { assignments, quizzes, tests, sessions, week, month, completionRate, upcoming, overdue };
  }, [events]);

  const workload = workloadLevel(stats.upcoming);

  return (
    <div className="glass rounded-3xl p-6 lg:col-span-2">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-lg font-semibold tracking-tight">Planner productivity</h3>
          <p className="text-sm text-muted-foreground">How your planner activity is trending.</p>
        </div>
        <span className={cn("text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-full border font-medium", workload.className)}>
          {workload.label} week ahead
        </span>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
        <Tile icon={CheckCircle2} label="Assignments completed" value={stats.assignments} />
        <Tile icon={ClipboardList} label="Quizzes taken" value={stats.quizzes} />
        <Tile icon={GraduationCap} label="Tests completed" value={stats.tests} />
        <Tile icon={Target} label="Study sessions" value={stats.sessions} />
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Small label="This week" value={stats.week} />
        <Small label="This month" value={stats.month} />
        <Small label="Completion rate" value={`${stats.completionRate}%`} />
        <Small label="Overdue" value={stats.overdue} highlight={stats.overdue > 0} />
      </div>
    </div>
  );
}

function Tile({ icon: Icon, label, value }: { icon: typeof TrendingUp; label: string; value: number }) {
  return (
    <div className="rounded-2xl border border-border bg-card/50 p-4">
      <Icon className="h-4 w-4 text-primary mb-2" />
      <div className="text-2xl font-semibold tabular-nums">{value}</div>
      <div className="text-xs text-muted-foreground mt-1">{label}</div>
    </div>
  );
}

function Small({ label, value, highlight }: { label: string; value: number | string; highlight?: boolean }) {
  return (
    <div className="rounded-xl border border-border bg-background/40 p-3">
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className={cn("text-lg font-semibold tabular-nums mt-0.5", highlight && "text-destructive")}>{value}</div>
    </div>
  );
}
