import { useEffect, useRef, useState } from "react";
import { TrendingUp, TrendingDown, Minus, Sparkles } from "lucide-react";

interface QuizResult {
  subject: string;
  percent: number;
  completed_at: string;
}

interface Props {
  results: QuizResult[];
}

function useCountUp(target: number, duration = 900) {
  const [value, setValue] = useState(target);
  const prev = useRef(target);
  useEffect(() => {
    const from = prev.current;
    const to = target;
    if (from === to) return;
    const start = performance.now();
    let raf = 0;
    const tick = (t: number) => {
      const p = Math.min(1, (t - start) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      setValue(Math.round(from + (to - from) * eased));
      if (p < 1) raf = requestAnimationFrame(tick);
      else prev.current = to;
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, duration]);
  return value;
}

function splitHalves<T>(arr: T[]): [T[], T[]] {
  if (arr.length < 2) return [[], []];
  const mid = Math.floor(arr.length / 2);
  return [arr.slice(0, mid), arr.slice(mid)];
}

function avg(nums: number[]) {
  if (!nums.length) return 0;
  return Math.round(nums.reduce((a, b) => a + b, 0) / nums.length);
}

const SUBJECTS = ["Math", "Science", "English", "History"] as const;

function normalizeSubject(s: string): string {
  const v = s.trim().toLowerCase();
  if (v.includes("math")) return "Math";
  if (v.includes("sci")) return "Science";
  if (v.includes("eng") || v.includes("language") || v.includes("ela")) return "English";
  if (v.includes("hist") || v.includes("social")) return "History";
  return s.trim();
}

function computeImprovement(items: QuizResult[]) {
  // items assumed sorted ascending by completed_at
  const [early, recent] = splitHalves(items);
  const earlyAvg = avg(early.map((r) => r.percent));
  const recentAvg = avg(recent.map((r) => r.percent));
  return { earlyAvg, recentAvg, delta: recentAvg - earlyAvg, count: items.length };
}

export function ImprovementCard({ results }: Props) {
  // Sort ascending
  const sorted = [...results].sort(
    (a, b) => new Date(a.completed_at).getTime() - new Date(b.completed_at).getTime()
  );

  const enough = sorted.length >= 2;
  const overall = computeImprovement(sorted);

  // Personal best detection: current recent avg is highest recent-half seen
  const [celebrate, setCelebrate] = useState(false);
  const prevBest = useRef<number | null>(null);
  useEffect(() => {
    if (!enough) return;
    if (prevBest.current !== null && overall.recentAvg > prevBest.current) {
      setCelebrate(true);
      const t = setTimeout(() => setCelebrate(false), 2200);
      return () => clearTimeout(t);
    }
    prevBest.current = overall.recentAvg;
  }, [overall.recentAvg, enough]);

  const dateRangeLabel = (() => {
    if (!sorted.length) return "";
    const first = new Date(sorted[0].completed_at);
    const days = Math.round((Date.now() - first.getTime()) / 86_400_000);
    if (days <= 30) return "Since First Quiz";
    return `Since ${first.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" })}`;
  })();

  const animatedDelta = useCountUp(enough ? overall.delta : 0);
  const animatedRecent = useCountUp(enough ? overall.recentAvg : 0);

  const trend =
    !enough || overall.delta === 0 ? "flat" : overall.delta > 0 ? "up" : "down";

  const trendColor =
    trend === "up"
      ? "text-success"
      : trend === "down"
      ? "text-destructive"
      : "text-muted-foreground";
  const trendBg =
    trend === "up"
      ? "bg-success/15 border-success/30"
      : trend === "down"
      ? "bg-destructive/15 border-destructive/30"
      : "bg-muted/40 border-border/70";
  const TrendIcon = trend === "up" ? TrendingUp : trend === "down" ? TrendingDown : Minus;

  // Subject breakdown
  const bySubject = new Map<string, QuizResult[]>();
  for (const r of sorted) {
    const key = normalizeSubject(r.subject);
    if (!SUBJECTS.includes(key as typeof SUBJECTS[number])) continue;
    const arr = bySubject.get(key) ?? [];
    arr.push(r);
    bySubject.set(key, arr);
  }
  const subjectRows = SUBJECTS.map((s) => {
    const items = bySubject.get(s) ?? [];
    return { subject: s, ...computeImprovement(items) };
  }).filter((r) => r.count >= 2);

  return (
    <div
      className={`glass rounded-3xl p-6 lg:col-span-2 relative overflow-hidden transition-shadow ${
        celebrate ? "shadow-[0_0_0_1px_hsl(var(--primary)/0.4),0_20px_60px_-20px_hsl(var(--primary)/0.5)]" : ""
      }`}
    >
      {celebrate && (
        <div className="absolute top-4 right-4 flex items-center gap-1.5 text-xs font-medium text-primary animate-fade-in">
          <Sparkles className="h-3.5 w-3.5" />
          New personal best!
        </div>
      )}

      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <h3 className="text-lg font-semibold tracking-tight">Quiz score improvement</h3>
          <p className="text-sm text-muted-foreground">
            Tracks how your average quiz performance changes over time.
          </p>
        </div>
        {enough && (
          <span className="text-xs text-muted-foreground px-2.5 py-1 rounded-full bg-accent border border-border/60">
            {dateRangeLabel}
          </span>
        )}
      </div>

      {!enough ? (
        <div className="mt-6 h-32 rounded-2xl border border-dashed border-border/70 flex items-center justify-center text-center px-4">
          <p className="text-sm text-muted-foreground">
            Complete a few quizzes to start tracking your improvement.
          </p>
        </div>
      ) : (
        <>
          <div className="mt-5 grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-4 rounded-2xl bg-background/60 border border-border/70">
              <div className="text-xs text-muted-foreground">Earlier average</div>
              <div className="mt-1 text-3xl font-semibold tracking-tight tabular-nums">
                {overall.earlyAvg}
                <span className="text-base text-muted-foreground">%</span>
              </div>
            </div>
            <div className="p-4 rounded-2xl bg-background/60 border border-border/70">
              <div className="text-xs text-muted-foreground">Current average</div>
              <div className="mt-1 text-3xl font-semibold tracking-tight tabular-nums text-primary">
                {animatedRecent}
                <span className="text-base text-muted-foreground">%</span>
              </div>
            </div>
            <div className={`p-4 rounded-2xl border ${trendBg}`}>
              <div className="text-xs text-muted-foreground">Change</div>
              <div className={`mt-1 flex items-center gap-2 text-3xl font-semibold tracking-tight tabular-nums ${trendColor}`}>
                <TrendIcon className="h-6 w-6" />
                {animatedDelta > 0 ? "+" : ""}
                {animatedDelta}
                <span className="text-base opacity-80">pts</span>
              </div>
            </div>
          </div>

          <p className="mt-4 text-sm text-foreground/90">
            Your average quiz score {trend === "up" ? "improved" : trend === "down" ? "decreased" : "held steady"} from{" "}
            <span className="font-semibold">{overall.earlyAvg}%</span> to{" "}
            <span className="font-semibold">{overall.recentAvg}%</span>.
          </p>

          {subjectRows.length > 0 && (
            <div className="mt-6">
              <div className="text-sm font-medium mb-2">By subject</div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {subjectRows.map((s) => {
                  const up = s.delta > 0;
                  const flat = s.delta === 0;
                  const Icon = flat ? Minus : up ? TrendingUp : TrendingDown;
                  const color = flat
                    ? "text-muted-foreground"
                    : up
                    ? "text-success"
                    : "text-destructive";
                  return (
                    <div
                      key={s.subject}
                      className="p-3 rounded-2xl bg-background/60 border border-border/70 flex items-center justify-between gap-3"
                    >
                      <div className="min-w-0">
                        <div className="text-sm font-medium truncate">{s.subject}</div>
                        <div className="text-xs text-muted-foreground tabular-nums">
                          {s.earlyAvg}% → {s.recentAvg}%
                        </div>
                      </div>
                      <div className={`flex items-center gap-1 text-sm font-semibold tabular-nums ${color}`}>
                        <Icon className="h-4 w-4" />
                        {s.delta > 0 ? "+" : ""}
                        {s.delta}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
