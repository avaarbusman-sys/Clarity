import { NavLink, Outlet, useLocation } from "react-router-dom";
import {
  LayoutDashboard,
  BookOpen,
  Sparkles,
  Layers,
  Brain,
  MessageCircle,
  CalendarDays,
  LineChart,
  UploadCloud,
  Settings as SettingsIcon,
  Menu,
  X,
} from "lucide-react";
import { PlannerReminders } from "@/components/planner/PlannerReminders";
import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";
import clarityLogo from "@/assets/clarity-logo.png.asset.json";
import { useStudyTimeTracker } from "@/hooks/useStudyTime";

const nav = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/subjects", label: "Subjects", icon: BookOpen },
  { to: "/study-guide", label: "Study Guide", icon: Sparkles },
  { to: "/flashcards", label: "Flashcards", icon: Layers },
  { to: "/quiz", label: "Quiz", icon: Brain },
  { to: "/tutor", label: "AI Tutor", icon: MessageCircle },
  { to: "/planner", label: "Planner", icon: CalendarDays },
  { to: "/progress", label: "Progress", icon: LineChart },
  { to: "/upload", label: "Upload", icon: UploadCloud },
  { to: "/settings", label: "Settings", icon: SettingsIcon },
];

export function AppLayout() {
  const [open, setOpen] = useState(false);
  const location = useLocation();
  useStudyTimeTracker();

  useEffect(() => setOpen(false), [location.pathname]);

  return (
    <div className="min-h-screen flex text-foreground">
      {/* Sidebar */}
      <aside
        className={cn(
          "fixed lg:static inset-y-0 left-0 z-40 w-72 p-4 transition-transform lg:translate-x-0",
          open ? "translate-x-0" : "-translate-x-full",
        )}
      >
        <div className="glass rounded-3xl h-full flex flex-col p-5">
          <div className="flex items-center gap-3 px-2 py-3">
            <img src={clarityLogo.url} alt="Clarity logo" className="h-10 w-10 rounded-2xl object-cover shadow-[var(--shadow-soft)]" />
            <div>
              <div className="text-lg font-semibold tracking-tight">Clarity</div>
              <div className="text-xs text-muted-foreground -mt-0.5">AI Study Companion</div>
            </div>
          </div>

          <nav className="mt-6 flex-1 space-y-1">
            {nav.map(({ to, label, icon: Icon }) => (
              <NavLink
                key={to}
                to={to}
                end
                className={({ isActive }) =>
                  cn(
                    "flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all",
                    isActive
                      ? "bg-primary/10 text-primary shadow-[var(--shadow-soft)]"
                      : "text-muted-foreground hover:text-foreground hover:bg-accent/60",
                  )
                }
              >
                <Icon className="h-4.5 w-4.5" size={18} />
                {label}
              </NavLink>
            ))}
          </nav>

          <div className="mt-4 p-4 rounded-2xl bg-gradient-to-br from-primary/10 to-primary-glow/10 border border-primary/10">
            <div className="text-xs font-medium text-primary">Prototype</div>
            <p className="text-xs text-muted-foreground mt-1 leading-relaxed">
              A visual concept of your AI study companion. All content is sample data.
            </p>
          </div>
        </div>
      </aside>

      {open && (
        <div
          className="fixed inset-0 z-30 bg-foreground/10 backdrop-blur-sm lg:hidden"
          onClick={() => setOpen(false)}
        />
      )}

      {/* Main */}
      <div className="flex-1 min-w-0 flex flex-col">
        <header className="lg:hidden sticky top-0 z-20 p-4">
          <div className="glass rounded-2xl px-4 py-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <img src={clarityLogo.url} alt="Clarity logo" className="h-8 w-8 rounded-xl object-cover" />
              <span className="font-semibold whitespace-pre">Clarity</span>
            </div>
            <button
              onClick={() => setOpen((v) => !v)}
              className="h-9 w-9 rounded-xl bg-accent/60 flex items-center justify-center"
              aria-label="Toggle navigation"
            >
              {open ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
            </button>
          </div>
        </header>

        <main key={location.pathname} className="flex-1 p-4 lg:p-8 animate-fade-in">
          <Outlet />
        </main>
      </div>
      <PlannerReminders />
    </div>
  );
}
