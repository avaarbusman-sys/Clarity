
# Planner Feature Plan

A full Planner section for Clarity that stores events in Lovable Cloud, integrates with Dashboard, Progress, and AI, and matches the existing blue/white glassmorphism style.

## 1. Database (new migration)

New table `public.planner_events`:
- `id`, `user_id`, `created_at`, `updated_at`
- `type` (`assignment` | `quiz` | `test` | `study_session`)
- `title`, `subject` (Math/Science/English/History/other), `description`
- `due_date` (date), `due_time` (time, nullable)
- `priority` (`low` | `medium` | `high`)
- `estimated_minutes` (int, nullable)
- `reminder` (`none`|`1w`|`3d`|`1d`|`3h`|`1h`|`at_due`)
- `repeat` (`none`|`daily`|`weekly`|`monthly`)
- Study-session extras: `duration_minutes`, `goal`, `linked_event_id` (FK self)
- `status` (`pending`|`completed`|`taken`)
- `completed_at` (nullable)

RLS: user-scoped. Grants for authenticated + service_role. `updated_at` trigger.

## 2. Routing & Nav

- Add `/planner` route in `src/App.tsx` between Tutor and Progress.
- Add sidebar item (CalendarDays icon) in `AppLayout.tsx` between "AI Tutor" and "Progress".

## 3. Planner page (`src/pages/Planner.tsx`)

Layout (glassmorphism, responsive):
- Header: title + search input + filter chips (subject, type, status) + sort (due date / priority) + view toggle (Month / Week / Day).
- Main grid:
  - Left/center: active view (Month calendar, Week agenda, Day schedule).
  - Right sidebar (collapses on mobile): "Today's Tasks", "Upcoming Events", workload indicator (Light/Moderate/Heavy based on next-7-day count), overdue banner at top.
- Floating `+ Add` button (bottom-right, gradient).

Views:
- **Month**: 7-col grid, today highlighted, colored dots per event type, click day → day sheet.
- **Week**: agenda list grouped by day for current week.
- **Day**: chronological list for selected day.

Event card: icon + accent color per type (Assignment blue, Quiz violet, Test rose, Study teal), title, subject chip, time, priority indicator, complete/taken checkbox, menu (edit, duplicate, delete).

Drag-drop: HTML5 DnD to move an event to another date on the month view (updates `due_date`).

## 4. Event modal (`src/components/planner/EventDialog.tsx`)

- Step 1: pick event type (4 tiles).
- Step 2: form with all fields per spec. Zod validation. Study session shows extra fields (duration, goal, linked event select).
- Same dialog reused for edit.

## 5. Data hook (`src/hooks/usePlannerEvents.ts`)

- React Query: `useEvents(filters)`, mutations for create/update/delete/duplicate/toggleComplete.
- Realtime subscription optional; invalidate queries after mutation is enough.

## 6. Dashboard integration

Add "Upcoming Planner" card on `Dashboard.tsx`:
- Due Today, This Week, Next Assignment/Quiz/Test/Study Session.
- Each row links to `/planner?event=<id>` which opens that event's day + edit dialog.

## 7. Progress integration

Add "Planner productivity" section in `Progress.tsx`:
- Counts: assignments completed, quizzes taken, tests completed, study sessions finished.
- Weekly + monthly completion rate, upcoming workload.

## 8. AI integration

Extend `supabase/functions/ai-chat/index.ts`:
- Accept optional `plannerContext` (list of upcoming events) in body.
- New system-prompt block: when user asks to plan/study for X, produce a numbered schedule referencing their real upcoming events (still guardrailed to 4 subjects).
- Client (`src/lib/ai.ts`) fetches next 14 days of events and passes them in for chat mode.

## 9. Notifications (in-app only)

- On app load + every minute, a light interval in `AppLayout` checks events whose reminder threshold just crossed and shows a `sonner` toast. No push/email (browser only, no service worker needed).

## 10. Technical notes

- Use `date-fns` (already available via shadcn calendar deps) for date math.
- All colors via existing semantic tokens (`primary`, `accent`, etc.); add 4 subtle CSS variables for event-type accents in `index.css`.
- No hardcoded hex; keep glassmorphism `glass` class.
- Types regenerated after migration approval; then wire up hook + pages.

## Order of implementation

1. Migration (approval gate).
2. Hook + Planner page shell + Month view + Add/Edit dialog.
3. Week + Day views, filters, search, sort, DnD, duplicate/complete.
4. Sidebar nav + route.
5. Dashboard + Progress integration.
6. AI planner context + notifications.
7. Polish + responsive pass.
